# Devil's AIdvocate

A reasoning coach that never gives the answer: it makes you commit to a view, tests it, and shows you how your thinking changed.

```
frontend/   the app — one HTML file (Person 1), now connected to the backend
ai/         prompts, Claude API client, guards, tests (Person 2)
backend/    API, privacy, anti-hallucination, RAG, Clarity Score, integration tests (Person 3)
```

## Run it

```bash
npm install                          # one install for everything
npx playwright install chromium      # only needed for the browser tests

npm run demo                         # http://localhost:8787 — demo stand-in for the AI, no key needed
npm start                            # live AI (Claude) — reads ANTHROPIC_API_KEY from backend/.env (see backend/.env.example)
open frontend/index.html             # offline: scripted replies, no server

npm test                             # AI layer (39 tests) + backend & browser end-to-end (43 tests)
```

The app picks its mode automatically and tells the user which one is active, in the disclosure banner, the top-bar badge, the source line under every reply and the privacy notice:

| Mode | When | Replies come from |
|---|---|---|
| Live | Server running with `ANTHROPIC_API_KEY` | Claude (Sonnet 5.5 for coaching, Haiku 5.5 for bias detection and the map) |
| Demo | `npm run demo` | A deterministic stand-in on the server — for demos and tests |
| Offline | HTML opened as a file, or no server | The scripted rules inside the page |

If the live AI fails mid-session, the app tells the user and continues on the scripted rules.

## Person 3 — what was built

| Plan task | Where | What it does |
|---|---|---|
| Backend API | `backend/src/server.js` | `GET /api/health`, `POST /api/respond`, `POST /api/clarity`; serves the app and Mermaid locally; input validation, size limit, rate limit, security headers and CSP. |
| Anti-hallucination layer | `backend/src/antiHallucination.js` | Every reply leaves with **source + confidence**. Citations not on the verified whitelist are removed. Statistics, "studies show…" and author–year citations the user never gave and no verified source backs are marked **"This is inferred — please verify in your context."** A reply without valid provenance is never sent (hard gate). |
| RAG pipeline | `backend/src/rag/` | A curated knowledge base of 19 research summaries (written for this project, one per whitelisted reference) with a local TF-IDF retriever. Retrieved notes are fed into the coaching prompts and shown under replies as "What the research found". No data leaves the server for retrieval. |
| Privacy enforcement | `backend/src/privacy.js` | Data minimisation (only needed fields, length caps, HTML stripped), redaction of emails, phone numbers, IBANs, card numbers, ID numbers and passwords **before** anything reaches the model, no server-side storage, logs with metadata only. |
| Clarity Score calculator | `backend/src/clarity.js` | Same six items as the frontend (depth of reasoning, biases caught, reflection engagement). New integrity rule on both sides: "Explained what changed" only counts in the user's **own words**, not copied from the coach. The server computes the score itself for the closing step — it never trusts the browser's number. |
| Dependency Tracker logic | `frontend/index.html` (Independence) | Counts AI sessions and solo attempts **in the browser only**. Nudges after 5 AI sessions in a day ("Try this next one alone — your brain needs reps too"), or a week with no solo attempt; celebrates solo attempts. |
| Connect backend to frontend | `frontend/index.html` | Live calls with scripted fallback; mode-aware disclosure, badge and privacy text; source and confidence badges; research notes; Reasoning Map dialog; solo-attempt dialog; 24 h / 3 d / 1 w practice challenges. |
| Integration test | `backend/test/run-tests.js` | 43 tests: unit, API and real-browser end-to-end (details below). |

### Frontend pieces added for the connection

Person 1's last-hour items weren't in the HTML yet, and the backend's data needs somewhere to appear, so minimal versions were added. Everything that was already there works as before, and the page still works on its own as a file.

- **Reasoning Map**: a sidebar button opens a diagram built from the backend's map (or from the session's own fields when offline). Unknowns are labelled as inferred, facts as "stated by you, not verified".
- **Independence panel**: AI sessions today, solo attempts this week, the current nudge, and a "Try one alone (no AI)" button. Solo attempts are saved locally and never sent anywhere.
- **Practice challenges**: sessions below 100% are scheduled for 24 hours, 3 days and 1 week later; when one is due it appears above the opening form.
- **Provenance under each live reply**: source line, "Source cited / Based on your own words / Inferred — please verify" badge, confidence badge, and expandable research notes.
- **Bias flags from the live detector**: the existing box gains "Why" and "Confidence" rows.

## How a request is handled

```
browser ──POST /api/respond {session, step, payload}──▶ server
  1. minimise     keep only the fields the AI needs; cap lengths; strip HTML
  2. redact       emails, phones, IBANs, cards, IDs, passwords → placeholders
  3. retrieve     top-3 research notes for this turn (RAG)
  4. respond      AI layer: coach / Socratic questions / bias detector / mapper / reflection
  5. enforce      whitelist citations, flag unsupported claims, attach source + confidence + evidence
  6. gate         no valid provenance → no reply
◀── { reply, newlyFlagged, mermaid?, clarity?, reviews?, privacy: { redactions, stored: false } }
```

## What the tests cover

- **Privacy**: each identifier type is redacted; ordinary numbers (20%, 2024, Level 4) are left alone; identifiers never appear in any request sent to the model; server logs never contain user text.
- **Anti-hallucination**: invented statistics, unbacked "studies show", invented citations and tampered references are caught or removed; every reply from every step passes the provenance gate.
- **RAG**: every reference has a summary; 9 labelled queries find the right research note.
- **Clarity Score**: the browser and server agree on the same session, including the own-words rule.
- **Browser end-to-end**:
  - full sessions at Level 1 and Level 4;
  - the map renders under the strict security policy;
  - the dependency nudge appears and a solo attempt is counted;
  - practice challenges are scheduled and appear when due;
  - distress worded without crisis keywords triggers the safety banner;
  - a typed email comes back redacted;
  - a failing AI falls back to the scripted rules;
  - offline file mode works with the original disclosure text.

## Known limits

- **Not yet run against the live Claude API.** All tests use the demo stand-in because no key was available. Run `npm run test:live` (in `ai/`) with a key, read the transcripts, then try `npm start` before the demo.
- Redaction is pattern-based. It catches identifiers, not names or health details, which is why the privacy notice still asks users not to enter them.
- Retrieval is keyword-based and English. German or Persian input still gets coached and scored in that language, but receives fewer research notes.
- Solo attempts are self-reported, and the dependency counts live in one browser.
- The rate limiter is in-memory, which is fine for a single demo server.
