// Integration tests for the backend and the connected frontend.
//   npm test            unit + API + browser end-to-end (needs: npx playwright install chromium)
//   npm run test:unit   unit + API only (no browser)
// Uses the mock model, so no API key is needed and results are deterministic.

import { fileURLToPath } from 'node:url';
import { redactText, minimise, redact } from '../src/privacy.js';
import { findUnsupportedClaims, enforce, assertProvenance, INFERRED_NOTE, modelName } from '../src/antiHallucination.js';
import { retrieve, KB } from '../src/rag/retriever.js';
import { clarity, copyRatio } from '../src/clarity.js';
import { createApp, rateLimiter } from '../src/server.js';
import { CITATIONS } from 'devils-aidvocate-ai';
import { parseEnv } from '../src/env.js';

const UNIT_ONLY = process.argv.includes('--unit');
const FRONTEND = fileURLToPath(new URL('../../frontend/index.html', import.meta.url));

let passed = 0, failed = 0;
const failures = [];
async function test(name, fn) {
  try { await fn(); passed++; console.log(`  ✓ ${name}`); }
  catch (e) { failed++; failures.push(`${name}: ${e.message}`); console.log(`  ✗ ${name}\n      ${e.message}`); }
}
function assert(c, m) { if (!c) throw new Error(m || 'assertion failed'); }
const eq = (a, b, m) => assert(JSON.stringify(a) === JSON.stringify(b), `${m || 'not equal'}: ${JSON.stringify(a)} !== ${JSON.stringify(b)}`);

function listen(app) {
  return new Promise(res => app.listen(0, '127.0.0.1', () => res(`http://127.0.0.1:${app.address().port}`)));
}
const post = (base, path, body) => fetch(base + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: typeof body === 'string' ? body : JSON.stringify(body) });

const ENTRY = {
  question: 'Should I switch my thesis topic?',
  position: 'I should switch to LLM-based process mining.',
  reason: "Because it's trending and my supervisor seemed interested.",
  confidence: 4,
};
const session = (extra = {}) => ({ id: 'test', level: 2, phase: 'think', entry: ENTRY, messages: [], flagged: [], ...extra });

/* ═════════════════ Unit: privacy ═════════════════ */
async function unitPrivacy() {
  console.log('\nPrivacy');
  await test('identifiers are redacted: email, phone, IBAN, card, ID number, secrets', () => {
    const { text, found } = redactText('Mail kimia@example.com, call +43 660 1234567 or 0660 1234567, IBAN AT61 1904 3002 3457 3201, card 4111 1111 1111 1111, SSN 123-45-6789, password: hunter2');
    for (const leak of ['kimia@example.com', '1234567', 'AT61', '4111', '123-45-6789', 'hunter2']) assert(!text.includes(leak), `leaked ${leak}: ${text}`);
    eq(Object.keys(found).sort(), ['card', 'email', 'iban', 'national_id', 'phone', 'secret']);
  });
  await test('ordinary numbers are left alone (percentages, years, durations, levels)', () => {
    const t = 'The salary is 20% higher, I started in 2024, it takes 3 years, Level 4, score 85, 1234 5678 9012 3456 is not a valid card';
    eq(redactText(t).text, t);
  });
  await test('minimise keeps only needed fields, caps text, strips HTML, maps scripted bias ids', () => {
    const m = minimise({ ...session(), secretField: 'x', entry: { ...ENTRY, position: 'p'.repeat(5000), extra: 1 }, flagged: ['popularity', 'authority'],
      messages: [{ type: 'ai', html: '<b>Hi</b> &amp; welcome' }, { type: 'user', text: 'hello' }, { type: 'divider' }, { type: 'final' }, { type: 'ai', html: 'closing' }] });
    assert(!('secretField' in m) && !('extra' in m.entry));
    eq(m.entry.position.length, 2000);
    eq(m.flagged, ['bandwagon', 'appeal_to_authority']);
    eq(m.messages, [{ type: 'ai', plain: 'Hi welcome' }, { type: 'user', text: 'hello' }], 'messages after the final answer are dropped');
  });
  await test('redact covers every user-written field and the payload', () => {
    const s = minimise(session({ assumption: 'only if a@b.co agrees', counterText: 'call 0660 1234567', messages: [{ type: 'user', text: 'x@y.org' }] }));
    const r = redact(s, { text: 'me@me.com', final: { position: 'p z@z.de', changed: 'c', confidence: 3 } });
    const all = JSON.stringify(r.session) + JSON.stringify(r.payload);
    assert(!/@[a-z]+\./.test(all) && !all.includes('1234567'), all);
    assert(r.redactions.email === 4 && r.redactions.phone === 1, JSON.stringify(r.redactions));
  });
}

/* ═════════════════ Unit: .env loading ═════════════════ */
async function unitEnv() {
  console.log('\n.env loading');
  await test('.env lines are parsed: quotes, comments, export, Windows line endings', () => {
    const v = parseEnv('# comment\r\nANTHROPIC_API_KEY=sk-ant-abc123\r\nexport PORT=9000\nQUOTED="sk-ant-x y"\nSINGLE=\'v\'\nINLINE=value # note\nbroken line\n');
    eq(v, { ANTHROPIC_API_KEY: 'sk-ant-abc123', PORT: '9000', QUOTED: 'sk-ant-x y', SINGLE: 'v', INLINE: 'value' });
  });
}

/* ═════════════════ Unit: anti-hallucination ═════════════════ */
async function unitAntiHallucination() {
  console.log('\nAnti-hallucination');
  const user = ["The salary is 20% higher and my friend loves it."];
  await test('statistics and numbers the user never gave are caught; the user\'s own numbers are not', () => {
    eq(findUnsupportedClaims('You said "20% higher".', user, false), []);
    const c = findUnsupportedClaims('Only 35% of startups survive 10 years.', user, false);
    assert(c.some(x => x.kind === 'statistic') && c.some(x => x.text === '10'), JSON.stringify(c));
  });
  await test('"studies show" needs a verified source; years in ordinary sentences are fine', () => {
    assert(findUnsupportedClaims('Studies show this works.', user, false).length === 1);
    eq(findUnsupportedClaims('Studies show this works.', user, true), []);
    eq(findUnsupportedClaims('By 2030 you might feel differently.', user, false), []);
  });
  await test('invented citations are caught; whitelisted ones pass', () => {
    assert(findUnsupportedClaims('As Smith et al. (2019) found, people regret this.', user, false).some(c => c.kind === 'unverified citation'));
    eq(findUnsupportedClaims('Toulmin (1958) calls this the warrant.', user, true), []);
  });
  const base = () => ({ reply: { html: 'What has to be true?', tag: CITATIONS.toulmin1958.behind, techniqueId: 'toulmin1958', state: {} }, model: 'claude-sonnet-5-5' });
  await test('every reply gets source + confidence + citations + research evidence', () => {
    const { reply } = enforce(base(), { mode: 'live', userTexts: user });
    eq([reply.provenance.generator, reply.provenance.confidence, reply.provenance.basis], ['Live AI model (Claude Sonnet 5.5)', 'high', 'research']);
    eq(reply.provenance.citations.map(c => c.id), ['toulmin1958']);
    assert(reply.evidence[0].id === 'toulmin1958' && reply.evidence[0].finding.length > 40);
  });
  await test('a reply with an unsupported claim is marked uncertain with the verify note', () => {
    const r = base(); r.reply.html += ' Most people regret switching.'; r.reply.tag = null; r.reply.techniqueId = null;
    const { reply } = enforce(r, { mode: 'live', userTexts: user });
    eq([reply.provenance.confidence, reply.provenance.basis, reply.provenance.note], ['uncertain', 'inferred', INFERRED_NOTE]);
  });
  await test('tampered citations are removed before they reach the user', () => {
    const r = base(); r.reply.tag = 'Made-up research (Doe, 2020).';
    r.reply.bias = 'Bandwagon effect'; r.reply.biasCitation = 'Fake, A. (2001). Not real.'; r.reply.biasCiteId = 'leibenstein1950'; r.reply.biasQuote = 'x';
    const { reply } = enforce(r, { mode: 'live', userTexts: user });
    assert(reply.tag === null && !reply.bias && reply.provenance.removed.length === 2, JSON.stringify(reply.provenance.removed));
  });
  await test('the gate refuses replies without valid provenance', () => {
    let threw = 0;
    for (const bad of [{}, { provenance: { confidence: 'sure', basis: 'research', generator: 'x', citations: [] } },
      { provenance: { confidence: 'high', basis: 'research', generator: 'x', citations: [{ id: 'fake2020', reference: 'x' }] } }]) {
      try { assertProvenance(bad); } catch { threw++; }
    }
    eq(threw, 3);
  });
  await test('model ids become readable names', () => { eq(modelName('claude-haiku-5-5'), 'Claude Haiku 5.5'); });
}

/* ═════════════════ Unit: RAG ═════════════════ */
async function unitRag() {
  console.log('\nRAG retrieval');
  await test('knowledge base covers every whitelisted citation, with original summaries', () => {
    eq(KB.map(n => n.id).sort(), Object.keys(CITATIONS).sort());
    assert(KB.every(n => n.finding.split(' ').length >= 20));
  });
  const cases = [
    ['My supervisor told me this is the right topic', 'walton1997'],
    ['Everyone is doing it and it is trending', 'leibenstein1950'],
    ["I've already invested two years, it would be a waste to stop", 'arkes1985'],
    ['My friend did it and it worked out great', 'tversky1973'],
    ['ChatGPT said this is the best option so I trust it', 'parasuraman2010'],
    ['It just feels right and I am excited about it', 'slovic2007'],
    ['I want to stay with my current job because it is familiar', 'samuelson1988'],
    ['I am definitely sure, I have no doubt', 'moore2008'],
    ['They offered a salary number first and I compare everything to it', 'tversky1974'],
  ];
  await test(`expected research note is in the top 3 for ${cases.length} labelled queries`, () => {
    const misses = cases.filter(([q, id]) => !retrieve(q).some(n => n.id === id));
    assert(!misses.length, `missed: ${misses.map(([q, id]) => `${id} ← "${q}"`).join('; ')}`);
  });
  await test('top-1 accuracy is at least 7/9', () => {
    const hits = cases.filter(([q, id]) => retrieve(q)[0]?.id === id).length;
    assert(hits >= 7, `${hits}/9`);
  });
  await test('step and flagged-bias boosts steer retrieval', () => {
    assert(retrieve('I think so', { boost: ['reflect_open'] })[0]?.id === 'flavell1979');
  });
}

/* ═════════════════ Unit: Clarity Score ═════════════════ */
async function unitClarity() {
  console.log('\nClarity Score calculator');
  const full = () => session({ assumption: 'only if x', counter: true, falsify: 'if y I would drop it',
    final: { position: 'new view', changed: 'I realised the evidence for my reason was weaker than I thought before.', confidence: 3 },
    messages: [{ type: 'ai', html: 'What has to be true for your reason to support your view?' }] });
  await test('a complete session scores 100 with the three dimension subtotals', () => {
    const c = clarity(full());
    eq(c.score, 100); eq(c.groups.map(g => `${g.got}/${g.max}`), ['35/35', '35/35', '30/30']);
  });
  await test('copying the coach\'s words into "what changed" does not earn the explanation points', () => {
    const s = full();
    s.messages.push({ type: 'ai', html: 'You weighed the risk that the research gap closes before you finish your thesis work.' });
    s.final.changed = 'I weighed the risk that the research gap closes before you finish your thesis work.';
    assert(copyRatio(s.final.changed, [s.messages[1].html]) > 0.5);
    const c = clarity(s);
    eq([c.score, c.missing], [85, ['explained']]);
  });
}

/* ═════════════════ API integration ═════════════════ */
async function api() {
  console.log('\nAPI (mock model)');
  const recorder = [];
  const app = createApp({ env: { DA_MOCK_LLM: '1', DA_RATE_LIMIT: '1000' }, recorder });
  const base = await listen(app);
  const logs = [];
  const origLog = console.log;
  console.log = (...a) => { if (typeof a[0] === 'string' && a[0].startsWith('{"t"')) logs.push(a.join(' ')); else origLog(...a); };
  try {
    await test('health reports mode and the no-storage promise', async () => {
      const h = await (await fetch(base + '/api/health')).json();
      eq([h.live, h.mode, h.storesUserData, h.redactsIdentifiers], [true, 'mock', false, true]);
    });
    await test('security headers and CSP are set on the app page', async () => {
      const r = await fetch(base + '/');
      assert(r.headers.get('content-security-policy').includes("connect-src 'self'") && r.headers.get('x-content-type-options') === 'nosniff');
    });
    const steps = [
      ['afterEntry', {}, s => s],
      ['thinkReply', { text: 'It only works if it is still an open research gap.' }, s => s],
      ['openChallenge', {}, s => ({ ...s, phase: 'challenge', assumption: 'It only works if it is still an open research gap.' })],
      ['challengeReply', { text: "They'd say it moves too fast, a real risk. If three papers already solve it, I would drop it." }, s => ({ ...s, phase: 'challenge' })],
      ['openReflect', {}, s => ({ ...s, phase: 'reflect' })],
      ['closing', { final: { position: 'Review related work first.', changed: 'The risk that the gap closes made me want evidence before switching topics.', confidence: 3 } }, s => ({ ...s, phase: 'done' })],
    ];
    for (const [step, payload, shape] of steps) {
      await test(`${step}: reply carries valid source + confidence`, async () => {
        const r = await post(base, '/api/respond', { session: shape(session()), step, payload });
        eq(r.status, 200);
        const body = await r.json();
        assert(body.reply.html && assertProvenance(body.reply));
        assert(!('violations' in body) && body.privacy.stored === false, 'internal notes must not leak');
      });
    }
    await test('personal identifiers never reach the model, and logs never contain user text', async () => {
      recorder.length = 0; logs.length = 0;
      const s = session({ entry: { ...ENTRY, reason: "Because it's trending — email kimia@example.com or call +43 660 1234567, IBAN AT61 1904 3002 3457 3201." } });
      const body = await (await post(base, '/api/respond', { session: s, step: 'afterEntry' })).json();
      const sent = JSON.stringify(recorder);
      assert(recorder.length >= 3, 'expected coach, bias and map calls');
      for (const leak of ['kimia@example.com', '1234567', 'AT61 1904']) assert(!sent.includes(leak), `${leak} reached the model`);
      eq(body.privacy.redactions, { email: 1, iban: 1, phone: 1 });
      assert(logs.length && logs.every(l => !l.includes('trending') && !l.includes('LLM-based')), 'user text in logs');
    });
    await test('retrieved research notes are passed into the coaching prompt (RAG)', async () => {
      recorder.length = 0;
      await post(base, '/api/respond', { session: session(), step: 'afterEntry' });
      assert(recorder.some(r => r.messages[0].content.includes('<research_notes>')));
    });
    await test('an unsupported claim from the model comes back marked "inferred — please verify"', async () => {
      const body = await (await post(base, '/api/respond', { session: session(), step: 'thinkReply', payload: { text: 'It only works if the gap stays open [[test:unsupported-claim]]' } })).json();
      eq([body.reply.provenance.confidence, body.reply.provenance.note], ['uncertain', INFERRED_NOTE]);
    });
    await test('closing ignores a Clarity Score sent by the browser and computes its own', async () => {
      const body = await (await post(base, '/api/respond', { session: session(), step: 'closing', payload: { final: { position: 'same', changed: 'nothing', confidence: 5 }, clarity: 100, missing: [] } })).json();
      assert(body.clarity.score === 30 && body.resurface.flag === true && body.reviews.length === 3, JSON.stringify(body.clarity));
    });
    await test('/api/clarity returns the same rules as the frontend', async () => {
      const c = await (await post(base, '/api/clarity', { session: session({ assumption: 'x', counter: true }) })).json();
      eq(c.score, 55);
    });
    await test('bad input: 400 for unknown step, 400 for bad JSON, 413 for oversized body, 404 for unknown path', async () => {
      eq((await post(base, '/api/respond', { session: session(), step: 'hack' })).status, 400);
      eq((await post(base, '/api/respond', '{oops')).status, 400);
      eq((await post(base, '/api/respond', { session: session({ entry: { ...ENTRY, reason: 'x'.repeat(120000) } }), step: 'afterEntry' })).status, 413);
      eq((await fetch(base + '/nope')).status, 404);
    });
  } finally {
    console.log = origLog;
    app.close();
  }

  await test('rate limiting returns 429 when exceeded', async () => {
    const lim = rateLimiter(3);
    eq([lim('a'), lim('a'), lim('a'), lim('a'), lim('b')], [true, true, true, false, true]);
    const small = createApp({ env: { DA_MOCK_LLM: '1', DA_RATE_LIMIT: '2' } });
    const b2 = await listen(small);
    const codes = [];
    for (let i = 0; i < 3; i++) codes.push((await post(b2, '/api/clarity', { session: session() })).status);
    small.close();
    eq(codes, [200, 200, 429]);
  });
  await test('without a key or mock, /api/respond is 503 and health says live: false', async () => {
    const off = createApp({ env: { DA_MOCK_LLM: '', ANTHROPIC_API_KEY: '' } });
    const b3 = await listen(off);
    const h = await (await fetch(b3 + '/api/health')).json();
    const code = (await post(b3, '/api/respond', { session: session(), step: 'afterEntry' })).status;
    off.close();
    eq([h.live, h.mode, code], [false, 'off', 503]);
  });
}

/* ═════════════════ Browser end-to-end ═════════════════ */
async function browser() {
  let chromium;
  try { ({ chromium } = await import('playwright')); } catch { console.log('\nBrowser tests skipped: install with `npm i -D playwright && npx playwright install chromium`'); return; }
  console.log('\nBrowser end-to-end');
  const b = await chromium.launch();

  const flow = async (pg, { level = 1, changed = 'The risk that the gap closes quickly made me want evidence before committing to a switch.', challenge = "They'd probably say the field moves too fast, which is a real risk. If three recent papers already solve it, I would drop the idea.", think = 'It only works if this is still an open research gap when I finish.' } = {}) => {
    if (level !== 1) { await pg.click('#levelBtn'); await pg.check(`input[name=level][value='${level}']`, { force: true }); await pg.click('button[value=confirm]'); }
    await pg.fill('#fQuestion', ENTRY.question);
    await pg.fill('#fPosition', ENTRY.position);
    await pg.fill('#fReason', ENTRY.reason);
    await pg.check("input[name=fConf][value='4']", { force: true });
    await pg.click('#entrySubmit');
    const reply = async () => { await pg.waitForFunction(() => !document.querySelector('#typingSlot .typing'), null, { timeout: 15000 }); await pg.waitForTimeout(150); };
    await reply();
    await pg.fill('#inputBox', think); await pg.keyboard.press('Enter'); await reply();
    await pg.click('#advanceBtn'); await reply();
    await pg.fill('#inputBox', challenge); await pg.keyboard.press('Enter'); await reply();
    await pg.click('#advanceBtn'); await reply();
    await pg.fill('#fFinal', 'I will spend two weeks reviewing related work before deciding.');
    await pg.fill('#fChanged', changed);
    await pg.check("input[name=fConf2][value='3']", { force: true });
    await pg.click('#reflectSubmit'); await reply();
  };
  const page = async (base, init) => {
    const ctx = await b.newContext({ viewport: { width: 1400, height: 900 } });
    if (init) await ctx.addInitScript(init);
    const pg = await ctx.newPage();
    pg.errors = [];
    pg.on('pageerror', e => pg.errors.push(e.message));
    pg.on('console', m => { if (m.type() === 'error') pg.errors.push(m.text()); });
    await pg.goto(base);
    await pg.waitForTimeout(400);
    return pg;
  };

  const app = createApp({ env: { DA_MOCK_LLM: '1', DA_RATE_LIMIT: '1000' } });
  const base = await listen(app);
  const origLog = console.log;
  console.log = (...a) => { if (!(typeof a[0] === 'string' && a[0].startsWith('{"t"'))) origLog(...a); };
  try {
    for (const level of [1, 4]) {
      await test(`Level ${level}: full session through the backend, every reply with source + confidence`, async () => {
        const pg = await page(base);
        assert((await pg.innerText('#aiDisclosure')).startsWith('Demo mode'), 'banner must say demo mode');
        await flow(pg, { level });
        const sources = await pg.$$eval('p.why', els => els.map(e => e.innerText).filter(t => /^source/i.test(t)));
        const aiCount = await pg.locator('.ai-bubble').count();
        eq(sources.length, aiCount, 'one source line per AI reply');
        assert(sources.slice(1).every(t => t.includes('Demo stand-in')), 'replies after the welcome come from the backend');
        assert((await pg.locator('.prov').count()) === aiCount - 1);
        const flag = await pg.locator('.bias-flag').first().innerText();
        assert(/Why/.test(flag) && /Confidence/.test(flag) && /Walton/.test(flag), flag);
        eq(await pg.innerText('#clarityVal'), '100%');
        await pg.click('#mapBtn');
        await pg.waitForSelector('#mapBox svg', { timeout: 8000 });
        assert(!pg.errors.length, pg.errors.join(' | '));
        await pg.context().close();
      });
    }

    await test('Clarity Score parity: browser and server agree, including the own-words rule', async () => {
      const pg = await page(base);
      await flow(pg, { changed: 'You started with I should switch to LLM-based process mining. Has your view changed and why or why not' });
      // ↑ copied from the coach's reflect message → no explanation points on either side
      const shown = await pg.innerText('#clarityVal');
      const stored = await pg.evaluate(() => { const d = JSON.parse(localStorage.getItem('mindmirror.v3')); return d.sessions.find(s => s.id === d.currentId); });
      const server = await (await post(base, '/api/clarity', { session: stored })).json();
      eq(shown, `${server.score}%`);
      eq(server.missing, ['explained']);
      await pg.context().close();
    });

    await test('Dependency tracker: 5 AI sessions today → nudge; a solo attempt is counted and celebrated', async () => {
      const today = Date.now();
      const pg = await page(base, `localStorage.setItem('devils-aidvocate.independence', JSON.stringify({ events: Array.from({ length: 5 }, (_, i) => ({ t: ${today} - i * 1000, type: 'ai' })), reviews: [], solos: [] }))`);
      eq(await pg.innerText('#aiToday'), '5');
      const nudge = await pg.locator('.nudge').innerText();
      assert(nudge.includes("You've used Devil's AIdvocate 5 times today"), nudge);
      await pg.click('.nudge [data-act=solo]');
      await pg.fill('#soloAnswer', 'I would keep my current topic because my data is ready.');
      await pg.click('#soloSave');
      eq(await pg.innerText('#soloWeek'), '1');
      assert((await pg.innerText('#indepNote')).includes('1 solo attempt this week'));
      const leaked = await pg.evaluate(() => performance.getEntriesByType('resource').filter(r => r.name.includes('/api/respond')).length);
      eq(leaked, 0, 'solo attempts must not call the AI');
      await pg.context().close();
    });

    await test('Spaced repetition: an incomplete session schedules 24h/3d/1w challenges; a due one appears as a practice card', async () => {
      const pg = await page(base);
      await flow(pg, { changed: 'nothing really changed for me' }); // explanation too short → Clarity 85% → flagged for review
      let dep = await pg.evaluate(() => JSON.parse(localStorage.getItem('devils-aidvocate.independence')));
      eq(dep.reviews.map(r => r.interval), ['24h', '3d', '1w']);
      await pg.evaluate(() => { const d = JSON.parse(localStorage.getItem('devils-aidvocate.independence')); d.reviews[0].dueAt = new Date(Date.now() - 1000).toISOString(); localStorage.setItem('devils-aidvocate.independence', JSON.stringify(d)); });
      await pg.reload(); await pg.waitForTimeout(400);
      await pg.click('#newBtn');
      const card = await pg.locator('.nudge').innerText();
      assert(/practice challenge/i.test(card) && card.includes('no AI'), card);
      await pg.context().close();
    });

    await test('Safety: distress without crisis keywords is caught by the model-side check', async () => {
      const pg = await page(base);
      await pg.fill('#fPosition', 'I think I should drop out of my course.');
      await pg.fill('#fReason', 'I am failing and I feel like a burden to everyone.');
      await pg.check("input[name=fConf][value='3']", { force: true });
      await pg.click('#entrySubmit');
      await pg.waitForSelector('.safety-banner', { timeout: 8000 });
      await pg.context().close();
    });

    await test('Privacy through the UI: an email typed by the user comes back redacted', async () => {
      const pg = await page(base);
      await pg.fill('#fPosition', 'I should email my professor at prof@uni.example about switching.');
      await pg.fill('#fReason', 'Because my supervisor seemed interested in it.');
      await pg.check("input[name=fConf][value='3']", { force: true });
      await pg.click('#entrySubmit');
      await pg.waitForFunction(() => document.querySelectorAll('.ai-bubble').length >= 2, null, { timeout: 8000 });
      const replyText = await pg.locator('.ai-bubble').nth(1).innerText();
      assert(replyText.includes('[email removed]') && !replyText.includes('prof@uni.example'), replyText);
      await pg.context().close();
    });
  } finally { console.log = origLog; app.close(); }

  await test('Fallback: if the AI fails, the session continues on scripted rules with a notice', async () => {
    const failing = createApp({ env: { DA_MOCK_LLM: 'fail' } });
    const fb = await listen(failing);
    console.log = (...a) => { if (!(typeof a[0] === 'string' && a[0].startsWith('{"t"'))) origLog(...a); };
    try {
      const pg = await page(fb);
      await flow(pg);
      assert((await pg.locator('.note').first().innerText()).includes('live AI is unavailable'));
      const last = await pg.$$eval('p.why', els => els.map(e => e.innerText).filter(t => /^source/i.test(t)).pop());
      assert(last.includes('Scripted heuristics'), last);
      eq(await pg.innerText('#clarityVal'), '100%');
      await pg.context().close();
    } finally { console.log = origLog; failing.close(); }
  });

  await test('Offline: opened as a file, the app keeps the scripted disclosure and works without a server', async () => {
    const pg = await page('file://' + FRONTEND);
    eq(await pg.innerText('#aiDisclosure'), 'You are interacting with a scripted reasoning tool, not a live AI model. Responses follow fixed rules — they can be wrong. You retain full responsibility for your own decisions.');
    await flow(pg);
    eq(await pg.innerText('#clarityVal'), '100%');
    assert(!pg.errors.length, pg.errors.join(' | '));
    await pg.context().close();
  });

  await b.close();
}

/* ───────────── main ───────────── */
console.log("Devil's AIdvocate — backend integration tests");
await unitPrivacy();
await unitEnv();
await unitAntiHallucination();
await unitRag();
await unitClarity();
await api();
if (!UNIT_ONLY) await browser();
console.log(`\n${passed} passed, ${failed} failed`);
if (failed) { console.log(failures.map(f => `  - ${f}`).join('\n')); process.exitCode = 1; }
