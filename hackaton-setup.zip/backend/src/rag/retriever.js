// RAG retriever over the curated research knowledge base (knowledge.json).
// TF-IDF with word bigrams + cosine similarity, fully local: no embeddings API, no data leaves the server.
// Retrieved notes are (1) passed into the coaching prompts and (2) shown as "What the research found".

import { readFileSync } from 'node:fs';
import { CITATIONS } from 'devils-aidvocate-ai';

export const KB = JSON.parse(readFileSync(new URL('./knowledge.json', import.meta.url), 'utf8'));

const STOP = new Set(('a an and are as at be been but by can could do does for from had has have he her his i if in into is it its ' +
  'me my of on or our she so than that the their them then there these they this to too us was we were what when which who why will with ' +
  'would you your am im ive dont not no yes just very really also about more most much should').split(' ')
  .concat('der die das und ist ich nicht ein eine zu mit auf für von sich es dass wenn aber oder auch noch nur so wie was'.split(' ')));

export function tokenize(text) {
  return (String(text ?? '').toLowerCase().normalize('NFKC').match(/[\p{L}\p{N}]+/gu) || [])
    .filter(t => t.length > 1 && !STOP.has(t));
}

function terms(text) {
  const raw = (String(text ?? '').toLowerCase().normalize('NFKC').match(/[\p{L}\p{N}]+/gu) || []);
  const uni = raw.filter(t => t.length > 1 && !STOP.has(t));
  const bi = raw.slice(1).map((w, i) => `${raw[i]} ${w}`); // bigrams keep stopwords: "my friend", "only works"
  return [...uni, ...bi];
}

function docText(d) {
  // keywords and tags carry more weight than prose
  return [d.title, d.finding, d.use, ...Array(3).fill(d.keywords.join(' ')), ...Array(2).fill(d.applies_to.join(' ').replace(/_/g, ' '))].join(' ');
}

const docs = KB.map(d => ({ d, tf: count(terms(docText(d))) }));
const df = new Map();
for (const { tf } of docs) for (const t of tf.keys()) df.set(t, (df.get(t) || 0) + 1);
const idf = t => Math.log((1 + docs.length) / (1 + (df.get(t) || 0))) + 1;
for (const doc of docs) doc.vec = weigh(doc.tf);

function count(list) { const m = new Map(); for (const t of list) m.set(t, (m.get(t) || 0) + 1); return m; }
function weigh(tf) {
  const v = new Map(); let norm = 0;
  for (const [t, c] of tf) { const w = (1 + Math.log(c)) * idf(t); v.set(t, w); norm += w * w; }
  norm = Math.sqrt(norm) || 1;
  for (const [t, w] of v) v.set(t, w / norm);
  return v;
}
function cosine(a, b) { let s = 0; for (const [t, w] of a) { const x = b.get(t); if (x) s += w * x; } return s; }

/**
 * @param {string} query            free text (the user's reasoning, latest reply…)
 * @param {object} [opts]
 * @param {number} [opts.k=3]
 * @param {string[]} [opts.boost]   tags or ids to favour (current step, flagged bias ids)
 * @param {number} [opts.minScore]  drop weak matches
 */
export function retrieve(query, { k = 3, boost = [], minScore = 0.04 } = {}) {
  const q = weigh(count(terms(query)));
  return docs
    .map(({ d, vec }) => {
      const hits = boost.filter(b => b === d.id || d.applies_to.includes(b)).length;
      return { d, score: cosine(q, vec) + 0.15 * hits };
    })
    .filter(r => r.score >= minScore)
    .sort((a, b) => b.score - a.score)
    .slice(0, k)
    .map(({ d, score }) => ({ id: d.id, title: d.title, finding: d.finding, reference: CITATIONS[d.id]?.reference || null, label: CITATIONS[d.id]?.label || d.id, score: +score.toFixed(3) }));
}

export function noteById(id) {
  const d = KB.find(n => n.id === id);
  return d ? { id: d.id, title: d.title, finding: d.finding, reference: CITATIONS[d.id]?.reference || null, label: CITATIONS[d.id]?.label || d.id } : null;
}

const STEP_TAG = {
  afterEntry: 'think_open', thinkReply: 'think_reply', openChallenge: 'challenge_open',
  challengeReply: 'challenge_reply', openReflect: 'reflect_open', closing: 'reflection_nudge',
};

/** Build the retrieval query for a turn from the (already minimised and redacted) session. */
export function retrieveForTurn(session, step, payload = {}) {
  const e = session.entry || {};
  const query = [e.position, e.reason, session.assumption, payload.text, payload.final?.changed].filter(Boolean).join(' ');
  return retrieve(query, { k: 3, boost: [STEP_TAG[step], ...(session.flagged || [])].filter(Boolean) });
}
