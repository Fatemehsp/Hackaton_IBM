// Devil's AIdvocate backend.
//
//   GET  /                      the app (frontend/index.html)
//   GET  /vendor/mermaid.min.js Mermaid, served locally (no third-party CDN when running on the server)
//   GET  /api/health            mode the frontend should use: live | mock | off
//   POST /api/respond           one AI turn:  privacy → RAG → AI layer → anti-hallucination
//   POST /api/clarity           Clarity Score for a session (same rules as the frontend)
//
// Modes
//   ANTHROPIC_API_KEY set  → live (Claude)
//   DA_MOCK_LLM=1          → mock (deterministic stand-in, labelled as a demo in the UI)
//   DA_MOCK_LLM=fail       → mock that always fails (to test the frontend fallback)
//   neither                → off (frontend keeps its scripted replies)

import { loadedEnvFiles } from './env.js'; // first: reads backend/.env before the AI layer starts
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { respond, setClient, CONFIG } from 'devils-aidvocate-ai';
import { minimise, redact, safeLog } from './privacy.js';
import { enforce } from './antiHallucination.js';
import { retrieveForTurn } from './rag/retriever.js';
import { clarity } from './clarity.js';
import { createMockClient } from './mockLLM.js';

const STEPS = new Set(['afterEntry', 'thinkReply', 'openChallenge', 'challengeReply', 'openReflect', 'closing']);
const MAX_BODY = 100_000;

export function createApp(opts = {}) {
  const env = { ...process.env, ...opts.env };
  const mode = env.DA_MOCK_LLM ? 'mock' : env.ANTHROPIC_API_KEY ? 'live' : 'off';
  if (mode === 'mock') setClient(createMockClient({ fail: env.DA_MOCK_LLM === 'fail', recorder: opts.recorder }));
  const frontendPath = opts.frontendPath || fileURLToPath(new URL('../../frontend/index.html', import.meta.url));
  const mermaidPath = resolveMermaid();
  const limiter = rateLimiter(Number(env.DA_RATE_LIMIT || 60));

  const headers = (type, extra = {}) => ({
    'content-type': type,
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    'permissions-policy': 'camera=(), microphone=(), geolocation=()',
    'cache-control': 'no-store',
    ...extra,
  });
  const CSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'";

  async function readJson(req) {
    let raw = '';
    for await (const chunk of req) { raw += chunk; if (raw.length > MAX_BODY) throw Object.assign(new Error('Request too large'), { status: 413, expose: true }); }
    try { return JSON.parse(raw || '{}'); } catch { throw Object.assign(new Error('Invalid JSON'), { status: 400, expose: true }); }
  }

  return createServer(async (req, res) => {
    const json = (status, body) => { res.writeHead(status, headers('application/json; charset=utf-8')); res.end(JSON.stringify(body)); };
    const url = new URL(req.url, 'http://local');
    const started = Date.now();
    try {
      if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
        res.writeHead(200, headers('text/html; charset=utf-8', { 'content-security-policy': CSP }));
        return res.end(readFileSync(frontendPath));
      }
      if (req.method === 'GET' && url.pathname === '/vendor/mermaid.min.js' && existsSync(mermaidPath)) {
        res.writeHead(200, headers('text/javascript; charset=utf-8', { 'cache-control': 'public, max-age=86400' }));
        return res.end(readFileSync(mermaidPath));
      }
      if (req.method === 'GET' && url.pathname === '/api/health') {
        return json(200, { ok: true, live: mode !== 'off', mode, model: mode === 'live' ? CONFIG.coachModel : null, storesUserData: false, redactsIdentifiers: true });
      }
      if (url.pathname.startsWith('/api/') && !limiter(req.socket.remoteAddress || 'unknown')) {
        return json(429, { error: 'Too many requests — please slow down.' });
      }
      if (req.method === 'POST' && url.pathname === '/api/clarity') {
        const { session } = await readJson(req);
        return json(200, clarity(minimise(session)));
      }
      if (req.method === 'POST' && url.pathname === '/api/respond') {
        if (mode === 'off') return json(503, { error: 'Live AI is not configured on this server.' });
        const body = await readJson(req);
        if (!body.session || !STEPS.has(body.step)) return json(400, { error: 'Expected { session, step, payload }' });

        // 1. privacy: minimise, then redact identifiers — before anything reaches the model
        const { session, payload, redactions } = redact(minimise(body.session), body.payload);
        if (body.step === 'closing') {
          if (!payload.final) return json(400, { error: 'closing needs payload.final' });
          session.final = payload.final;
          const c = clarity(session);                 // computed here — never trusted from the browser
          payload.clarity = c.score; payload.missing = c.missing;
        }
        // 2. RAG: retrieve research notes for this turn
        const research = retrieveForTurn(session, body.step, payload);
        // 3. AI layer (Person 2)
        const result = await respond(session, body.step, payload, { research });
        // 4. anti-hallucination: source + confidence on every reply, unverifiable citations removed
        const userTexts = [session.entry?.question, session.entry?.position, session.entry?.reason, session.assumption, payload.text,
          payload.final?.position, payload.final?.changed, ...session.messages.filter(m => m.type === 'user').map(m => m.text)].filter(Boolean);
        const checked = enforce(result, { mode, userTexts });
        if (body.step === 'closing') checked.clarity = clarity(session);

        safeLog({ step: body.step, level: session.level, ms: Date.now() - started, status: 200, mode, fallback: checked.usedFallback,
          redactions: Object.values(redactions).reduce((a, b) => a + b, 0), confidence: checked.reply.provenance.confidence });
        // the browser gets the reply, never the internal guard notes
        const { violations, ...publicResult } = checked;
        return json(200, { ...publicResult, model: mode === 'live' ? result.model : null, privacy: { redactions, stored: false } });
      }
      json(404, { error: 'Not found' });
    } catch (err) {
      const status = err.expose ? err.status : 502; // AI/API errors (bad key, no credit…) never reach the browser
      // API errors (wrong key, no credit, model name) are logged for the operator — they never contain user text
      const detail = status === 502 ? String(err.status ? `${err.status} ${err.error?.error?.type || ''} ${err.error?.error?.message || err.message}` : err.message).slice(0, 200) : undefined;
      safeLog({ status, ms: Date.now() - started, error: err.kind || (status === 502 ? 'ai_error' : 'bad_request'), detail });
      json(status, { error: status === 502 ? 'The AI service is unavailable right now.' : err.message });
    }
  });
}

/** Locate Mermaid's browser bundle wherever npm installed it (package folder or hoisted to the root). */
function resolveMermaid() {
  try { return join(dirname(createRequire(import.meta.url).resolve('mermaid')), 'mermaid.min.js'); } catch { return ''; }
}

/** Simple per-IP limiter: `perMinute` requests in any rolling minute. */
export function rateLimiter(perMinute) {
  const hits = new Map();
  return ip => {
    const now = Date.now();
    const list = (hits.get(ip) || []).filter(t => now - t < 60_000);
    if (list.length >= perMinute) { hits.set(ip, list); return false; }
    list.push(now); hits.set(ip, list);
    return true;
  };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 8787);
  createApp().listen(port, () => {
    const key = process.env.ANTHROPIC_API_KEY || '';
    const mode = process.env.DA_MOCK_LLM ? 'demo (stand-in, no key used)' : key ? `live — Claude (${CONFIG.coachModel})` : 'off — scripted replies only';
    console.log(`Devil's AIdvocate running on http://localhost:${port}`);
    console.log(`  settings file: ${loadedEnvFiles.length ? loadedEnvFiles.join(', ') : 'none found (looked for backend/.env)'}`);
    console.log(`  AI mode: ${mode}`);
    if (!key && !process.env.DA_MOCK_LLM) {
      if (process.env.OPENAI_API_KEY) console.log('  Note: found OPENAI_API_KEY, but this app uses the Claude API. Add ANTHROPIC_API_KEY=... to backend/.env');
      else console.log('  Tip: add ANTHROPIC_API_KEY=... to backend/.env for live AI, or run "npm run demo".');
    } else if (key && !key.startsWith('sk-ant-')) {
      console.log('  Warning: ANTHROPIC_API_KEY does not start with "sk-ant-" — check that it is a Claude API key.');
    }
  });
}
