// Clarity Score calculator (server side).
// Same six items and weights as the frontend, so both always agree (checked by the integration test).
// Three dimensions from the concept: depth of reasoning, biases caught, reflection engagement.
// Integrity rule: "Explained what changed" only counts if the explanation is in the user's OWN words,
// not copied from the coach — the concept's "changed their view based on their own reflection, not AI output".

export const GROUPS = [
  { key: 'depth', label: 'Depth of reasoning' },
  { key: 'bias', label: 'Biases caught' },
  { key: 'reflect', label: 'Reflection engagement' },
];

const wc = s => String(s ?? '').trim().split(/\s+/).filter(Boolean).length;
const stripHtml = s => String(s ?? '').replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ');
const words = s => (String(s ?? '').toLowerCase().match(/[\p{L}\p{N}']+/gu) || []);

function shingles(list, n = 4) {
  const out = new Set();
  for (let i = 0; i + n <= list.length; i++) out.add(list.slice(i, i + n).join(' '));
  return out;
}

/** Share (0–1) of the user's text that appears word-for-word in the coach's messages, in 4-word runs. */
export function copyRatio(userText, coachTexts) {
  const mine = shingles(words(userText));
  if (!mine.size) return 0;
  const theirs = new Set();
  for (const t of coachTexts) for (const sh of shingles(words(t))) theirs.add(sh);
  let copied = 0;
  for (const sh of mine) if (theirs.has(sh)) copied++;
  return copied / mine.size;
}

export function coachTexts(session) {
  return (session.messages || []).filter(m => m.type === 'ai').map(m => m.plain ?? stripHtml(m.html));
}

export function ownWords(session) {
  return !!session.final && copyRatio(session.final.changed, coachTexts(session)) < 0.5;
}

export function items(s) {
  return [
    { key: 'stance', group: 'depth', pts: 15, label: 'Stated a position with a reason', done: !!(s.entry && wc(s.entry.position) >= 3 && wc(s.entry.reason) >= 3) },
    { key: 'assumption', group: 'depth', pts: 20, label: 'Named an underlying assumption', done: !!s.assumption },
    { key: 'counter', group: 'bias', pts: 20, label: 'Engaged with the other side', done: !!s.counter },
    { key: 'falsify', group: 'bias', pts: 15, label: 'Said what would change your mind', done: !!s.falsify },
    { key: 'reflection', group: 'reflect', pts: 15, label: 'Completed the reflection', done: !!s.final },
    { key: 'explained', group: 'reflect', pts: 15, label: 'Explained what changed, or why not', done: !!(s.final && wc(s.final.changed) >= 10 && ownWords(s)) },
  ];
}

export function clarity(session) {
  const list = items(session);
  return {
    score: list.reduce((a, x) => a + (x.done ? x.pts : 0), 0),
    groups: GROUPS.map(g => {
      const mine = list.filter(x => x.group === g.key);
      return { ...g, got: mine.filter(x => x.done).reduce((a, x) => a + x.pts, 0), max: mine.reduce((a, x) => a + x.pts, 0) };
    }),
    items: list,
    missing: list.filter(x => !x.done).map(x => x.key),
  };
}
