// Privacy enforcement — applied to every request BEFORE anything reaches the AI model.
//  1. Data minimisation: only the session fields the AI needs, with length caps.
//  2. Redaction: personal identifiers are replaced with placeholders.
//  3. No storage: the server keeps nothing; logs carry metadata only, never user text.

const MAX_TEXT = 2000;
const MAX_MESSAGES = 30;

// Scripted (in-browser) bias keys → AI-layer bias ids, so a session that mixed both modes isn't flagged twice.
const LOCAL_BIAS_IDS = { authority: 'appeal_to_authority', popularity: 'bandwagon', absolute: 'overgeneralisation', overconfidence: 'overconfidence', confirmation: 'confirmation_bias' };

const cap = s => (typeof s === 'string' ? s.slice(0, MAX_TEXT) : '');
const stripHtml = s => cap(String(s ?? '').replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ').replace(/\s+/g, ' ').trim());
const num = (v, lo, hi, d) => (Number.isFinite(+v) ? Math.min(hi, Math.max(lo, Math.round(+v))) : d);

// Everything after the user's final answer (summary, closing message) is irrelevant to the AI and to scoring.
const beforeFinal = list => { const i = list.findIndex(m => m && m.type === 'final'); return i === -1 ? list : list.slice(0, i); };

/** Keep only what the AI layer reads. Everything else the browser sent is dropped. */
export function minimise(session = {}) {
  const e = session.entry || null;
  const f = session.final || null;
  return {
    id: typeof session.id === 'string' ? session.id.slice(0, 40) : 'session',
    level: num(session.level, 1, 4, 1),
    phase: ['think', 'challenge', 'reflect', 'done'].includes(session.phase) ? session.phase : 'think',
    entry: e && { question: cap(e.question), position: cap(e.position), reason: cap(e.reason), confidence: num(e.confidence, 1, 5, 3) },
    final: f && { position: cap(f.position), changed: cap(f.changed), confidence: num(f.confidence, 1, 5, 3) },
    assumption: session.assumption ? cap(session.assumption) : null,
    counter: !!session.counter,
    counterText: session.counterText ? cap(session.counterText) : null,
    falsify: session.falsify ? cap(session.falsify) : null,
    thinkReplies: num(session.thinkReplies, 0, 99, 0),
    challengeReplies: num(session.challengeReplies, 0, 99, 0),
    flagged: [...new Set((Array.isArray(session.flagged) ? session.flagged : []).map(k => LOCAL_BIAS_IDS[k] || String(k)).slice(0, 20))],
    messages: beforeFinal(Array.isArray(session.messages) ? session.messages : [])
      .filter(m => m && (m.type === 'user' || m.type === 'ai'))
      .slice(-MAX_MESSAGES)
      .map(m => (m.type === 'user' ? { type: 'user', text: cap(m.text) } : { type: 'ai', plain: stripHtml(m.html) })),
  };
}

/* ───────────── Redaction ───────────── */

function luhn(digits) {
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = +digits[i];
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n; alt = !alt;
  }
  return sum % 10 === 0;
}

const RULES = [
  { type: 'secret', re: /\b(password|passwort|passcode|pwd|pin|api[ _-]?key|token)\s*(?:is|:|=)\s*\S+/gi, replace: (m, k) => `${k}: [secret removed]` },
  { type: 'email', re: /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, replace: () => '[email removed]' },
  { type: 'iban', re: /\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){3,7}(?:[ ]?[A-Z0-9]{1,3})?\b/g, replace: () => '[IBAN removed]' },
  { type: 'card', re: /\b(?:\d[ -]?){13,19}\b/g, test: m => luhn(m.replace(/\D/g, '')), replace: () => '[card number removed]' },
  { type: 'national_id', re: /\b\d{3}-\d{2}-\d{4}\b/g, replace: () => '[ID number removed]' },
  { type: 'phone', re: /(?:\+|\b00)\d{1,3}[\s./-]?\(?\d{1,4}\)?(?:[\s./-]?\d{2,4}){2,4}\b|\b0\d{2,4}[\s/-]?\d{3,4}[\s-]?\d{2,5}\b/g, replace: () => '[phone removed]' },
];

/** Redact one string. Returns { text, found: { type: count } }. */
export function redactText(text) {
  let out = String(text ?? '');
  const found = {};
  for (const rule of RULES) {
    out = out.replace(rule.re, (...args) => {
      const m = args[0];
      if (rule.test && !rule.test(m)) return m;
      found[rule.type] = (found[rule.type] || 0) + 1;
      return rule.replace(...args);
    });
  }
  return { text: out, found };
}

/** Redact every user-written field of a minimised session and the payload (in place on copies). */
export function redact(session, payload = {}) {
  const totals = {};
  const r = s => {
    if (typeof s !== 'string' || !s) return s;
    const { text, found } = redactText(s);
    for (const [k, v] of Object.entries(found)) totals[k] = (totals[k] || 0) + v;
    return text;
  };
  const s = structuredClone(session);
  if (s.entry) for (const k of ['question', 'position', 'reason']) s.entry[k] = r(s.entry[k]);
  if (s.final) for (const k of ['position', 'changed']) s.final[k] = r(s.final[k]);
  for (const k of ['assumption', 'counterText', 'falsify']) s[k] = r(s[k]);
  for (const m of s.messages) if (m.type === 'user') m.text = r(m.text);
  const p = structuredClone(payload || {});
  if (typeof p.text === 'string') p.text = cap(r(p.text));
  if (p.final) p.final = { position: cap(r(p.final.position)), changed: cap(r(p.final.changed)), confidence: num(p.final.confidence, 1, 5, 3) };
  return { session: s, payload: p, redactions: totals };
}

/** Log line with metadata only. Never pass user text here. */
export function safeLog(fields) {
  const allowed = ['step', 'level', 'ms', 'status', 'mode', 'fallback', 'redactions', 'calls', 'confidence', 'error', 'detail'];
  const clean = Object.fromEntries(Object.entries(fields).filter(([k]) => allowed.includes(k)));
  console.log(JSON.stringify({ t: new Date().toISOString(), ...clean }));
}
