// Anti-hallucination layer — every reply leaves the server with a source and a confidence field.
//
//   source:      who generated it (live model / demo stand-in) + what it rests on
//                (your own words, verified research, or inference)
//   confidence:  high | medium | uncertain
//   citations:   only from the verified whitelist — anything else is removed
//   note:        "This is inferred — please verify in your context." when the reply makes a claim
//                that is neither in the user's words nor backed by a whitelisted source
//
// assertProvenance() is the hard gate: a reply without valid provenance is never sent.

import { CITATIONS } from 'devils-aidvocate-ai';
import { noteById } from './rag/retriever.js';

export const CONFIDENCE = ['high', 'medium', 'uncertain'];
export const BASIS = ['user_words', 'research', 'inferred'];
export const INFERRED_NOTE = 'This is inferred — please verify in your context.';

const strip = html => String(html ?? '').replace(/<[^>]+>/g, ' ').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
const norm = s => String(s ?? '').toLowerCase().replace(/\s+/g, ' ');

const CLAIMS = [
  { kind: 'statistic', re: /\b\d+(?:[.,]\d+)?\s?(?:%|percent|per cent|prozent)/gi },
  { kind: 'research claim', re: /\b(?:studies|research|science|the data|evidence|experts?|surveys?|statistics)\s+(?:show|shows|prove|proves|suggest|suggests|say|says|found|finds|confirm|confirms|agree|agrees)\b/gi },
  { kind: 'asserted fact', re: /\b(?:it is (?:a )?(?:proven|fact|well[- ]known)|scientifically proven|statistically|on average|the majority of people|most people)\b/gi },
  { kind: 'number', re: /\b\d{2,}(?:[.,]\d+)?\b/g },
];
// "Name (2019)", "Name, 2019", "Name et al. (2019)", "Name & Other, 2019" — but not "In 2026" or "By 2030"
const AUTHOR_YEAR = /\b([A-Z][\p{L}'-]+)(?:\s+et al\.)?(?:,?\s+(?:and|&)\s+[A-Z][\p{L}'-]+)?(?:,\s*|\s+\()((?:1[89]|20)\d{2})\)?/gu;

const whitelistLabels = Object.values(CITATIONS).map(c => c.label.toLowerCase());

/** Find claims in the coach's text that the user never made and no whitelisted source backs. */
export function findUnsupportedClaims(replyText, userTexts, hasCitation) {
  const text = strip(replyText);
  const user = norm(userTexts.join(' \n '));
  const out = [];
  for (const { kind, re } of CLAIMS) {
    for (const m of text.matchAll(re)) {
      const span = m[0];
      if (kind === 'number' || kind === 'statistic') {
        const n = span.match(/\d+(?:[.,]\d+)?/)[0];
        if (user.includes(n)) continue;                         // the user said it
        if (kind === 'number' && /^(1[89]|20)\d{2}$/.test(n)) continue; // a year — checked as a citation below
      } else if (hasCitation) continue;                          // general research claim backed by a verified source
      out.push({ kind, text: span });
    }
  }
  for (const m of text.matchAll(AUTHOR_YEAR)) {
    const ok = whitelistLabels.some(l => l.includes(m[1].toLowerCase()) && l.includes(m[2]));
    if (!ok) out.push({ kind: 'unverified citation', text: m[0] });
  }
  // de-duplicate (a statistic is also a number)
  const seen = new Set();
  return out.filter(c => { const k = c.text.replace(/\D/g, '') || c.text; if (seen.has(k)) return false; seen.add(k); return true; });
}

/**
 * Attach provenance + evidence to a reply from the AI layer, and remove anything unverifiable.
 * @param {object} result   output of respond()
 * @param {object} ctx      { mode: 'live'|'mock', userTexts: string[] }
 */
export function enforce(result, { mode, userTexts }) {
  const reply = { ...result.reply };
  const removed = [];

  // 1. Technique citation must be on the whitelist and its text must match exactly.
  const tech = reply.techniqueId && CITATIONS[reply.techniqueId];
  if (reply.tag && (!tech || tech.behind !== reply.tag)) { removed.push('unverified technique citation'); reply.tag = null; reply.techniqueId = null; }

  // 2. Bias flag: citation must be the whitelisted reference for that bias.
  if (reply.bias) {
    const c = reply.biasCiteId && CITATIONS[reply.biasCiteId];
    if (!c || c.reference !== reply.biasCitation) {
      removed.push('unverified bias citation');
      for (const k of ['bias', 'biasCitation', 'biasQuote', 'biasExplanation', 'biasId', 'biasConfidence', 'biasCiteId']) delete reply[k];
    }
  }

  const citations = [reply.techniqueId, reply.biasCiteId].filter(Boolean)
    .filter((id, i, a) => a.indexOf(id) === i)
    .map(id => ({ id, label: CITATIONS[id].label, reference: CITATIONS[id].reference }));

  // 3. Claims in the visible text that nobody can back up.
  const visible = [reply.html, reply.biasExplanation].filter(Boolean).join(' ');
  const unsupported = reply.safety ? [] : findUnsupportedClaims(visible, userTexts, citations.length > 0);

  reply.provenance = {
    generator: mode === 'live' ? `Live AI model (${modelName(result.model)})` : 'Demo stand-in for the AI model (not a live model)',
    mode,
    basis: unsupported.length ? 'inferred' : citations.length ? 'research' : 'user_words',
    confidence: unsupported.length ? 'uncertain' : 'high',
    citations,
    inferred: unsupported.length > 0,
    unsupportedClaims: unsupported,
    note: unsupported.length ? INFERRED_NOTE : null,
    removed,
  };
  if (reply.bias) reply.biasConfidence = CONFIDENCE.includes(reply.biasConfidence) ? reply.biasConfidence : 'medium';

  // 4. Evidence cards from the curated knowledge base (RAG) for every cited source.
  reply.evidence = citations.map(c => noteById(c.id)).filter(Boolean);

  assertProvenance(reply);
  return { ...result, reply };
}

/** Hard gate: throws if a reply would leave without a valid source + confidence. */
export function assertProvenance(reply) {
  const p = reply && reply.provenance;
  if (!p) throw new Error('Provenance missing');
  if (!CONFIDENCE.includes(p.confidence)) throw new Error('Invalid confidence');
  if (!BASIS.includes(p.basis)) throw new Error('Invalid basis');
  if (!p.generator) throw new Error('Source missing');
  for (const c of p.citations) if (!CITATIONS[c.id] || CITATIONS[c.id].reference !== c.reference) throw new Error(`Citation not on whitelist: ${c.id}`);
  if (p.inferred && p.note !== INFERRED_NOTE) throw new Error('Inferred reply without verify note');
  return true;
}

export function modelName(id) {
  const m = /^claude-(\w+)-(\d+)-(\d+)$/.exec(id || '');
  return m ? `Claude ${m[1][0].toUpperCase()}${m[1].slice(1)} ${m[2]}.${m[3]}` : (id || 'unknown model');
}
