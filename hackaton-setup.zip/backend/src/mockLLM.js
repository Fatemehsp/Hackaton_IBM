// Deterministic stand-in for the Claude API, used for demos without an API key and for tests.
// It answers in the same JSON shapes as the real model, quoting the user's own words, so the whole
// pipeline (guards, provenance, privacy, UI) runs end to end. The UI labels it clearly as a demo.
//
//   createMockClient({ fail: true })      every call throws (tests the frontend fallback)
//   createMockClient({ recorder: [] })    every request is pushed into the array (privacy tests)

import { COACH_SCHEMA, SOCRATIC_SCHEMA, BIAS_SCHEMA, MAP_SCHEMA, REFLECTION_SCHEMA } from 'devils-aidvocate-ai/src/schemas.js';

const field = (input, name) => {
  const m = new RegExp(`<user_content field="${name}">([\\s\\S]*?)</user_content>`).exec(input);
  return m ? m[1].trim() : '';
};
const sentenceWith = (text, re) => {
  const m = re.exec(text);
  if (!m) return null;
  const before = text.slice(0, m.index), after = text.slice(m.index);
  const start = Math.max(before.lastIndexOf('.'), before.lastIndexOf('!'), before.lastIndexOf('?')) + 1;
  const end = after.search(/[.!?](\s|$)/);
  return text.slice(start, end === -1 ? text.length : m.index + end + 1).trim();
};
const wc = s => String(s || '').trim().split(/\s+/).filter(Boolean).length;
const short = (t, n = 60) => (t.length <= n ? t : t.slice(0, n).replace(/\s+\S*$/, '') + '…');
const none = { present: false, quote: null };

const RE = {
  assumption: /\b(only works if|only if|assum\w*|depends on|as long as|provided that|unless|funktioniert nur,? wenn|nur wenn)\b/i,
  engaged: /\b(but|however|they'?d (probably )?say|they would say|someone might|risk|fair point|might be wrong|man könnte|stimmt teilweise)\b/i,
  falsifier: /\b(if [^.]*?(i'?d|i would|i will)\s+(drop|change|turn|reconsider|stop|decline)|würde ich|would change my mind)/i,
  distress: /\b(don'?t see the point|no point in going on|burden to everyone|give up on everything|nicht mehr weiter)\b/i,
};

function coach(input, level) {
  const task = (/TASK: (\w+)/.exec(input) || [])[1];
  const latest = field(input, 'latest');
  const position = field(input, 'position');
  const reason = field(input, 'main_reason');
  const out = { message: '', question: '', hint: null, panel: [], technique_id: null, pending: 'none', can_advance: false,
    signals: { named_assumption: none, engaged_other_side: none, stated_falsifier: none }, safety_concern: false };

  if (RE.distress.test(latest) || RE.distress.test(reason)) {
    return { ...out, message: 'It sounds like things are heavy right now. Please reach out to someone you trust or a support line — that matters more than this decision.', safety_concern: true };
  }
  const sig = (re, text) => { const q = sentenceWith(text, re); return q ? { present: true, quote: q } : none; };
  if (latest && wc(latest) >= 4) {
    out.signals = { named_assumption: sig(RE.assumption, latest), engaged_other_side: sig(RE.engaged, latest), stated_falsifier: sig(RE.falsifier, latest) };
  }

  if (task === 'think_open') {
    Object.assign(out, { message: `You think "${position}", mainly because "${reason}".`, question: 'What has to be true for that reason to support your view?',
      hint: level === 1 ? 'Try finishing: "This only works if…"' : null, pending: 'assumption', technique_id: 'toulmin1958' });
  } else if (task === 'think_reply') {
    if (wc(latest) < 4) Object.assign(out, { message: 'That is too short to work with.', question: 'What does your reason depend on?', pending: 'assumption' });
    else if (out.signals.named_assumption.present) Object.assign(out, { message: `That is the link: "${out.signals.named_assumption.quote}"`, question: level === 2 ? 'What would you expect to see if you were wrong?' : 'How do you know that holds?', pending: level === 2 ? 'falsify' : 'evidence', can_advance: true, technique_id: 'toulmin1958' });
    else Object.assign(out, { message: 'That adds detail, but not the assumption yet.', question: 'What has to be true for your reason to lead to your conclusion?', hint: level === 1 ? 'Try: "This only works if…"' : null, pending: 'assumption', can_advance: /turns_in_step: [2-9]/.test(input), technique_id: 'toulmin1958' });
  } else if (task === 'challenge_reply') {
    const s = out.signals;
    const engagedBefore = /other_side_engaged: yes/.test(input);
    out.can_advance = engagedBefore || s.engaged_other_side.present || /turns_in_step: [3-9]/.test(input);
    out.pending = !(engagedBefore || s.engaged_other_side.present) ? 'counter' : s.stated_falsifier.present ? 'none' : 'falsify';
    if (level === 4) {
      out.panel = s.stated_falsifier.present ? [] : [{ critic: 'Premortem', objection: 'You have not said what result would make you abandon this.' }];
      out.message = s.engaged_other_side.present ? 'The panel accepts part of that.' : 'Insufficient: the objections are still open.';
    } else {
      out.message = s.engaged_other_side.present ? `You weighed the other side: "${s.engaged_other_side.quote}"` : 'You restated your position.';
    }
    out.question = out.pending === 'counter' ? 'What is the strongest point against your view?' : out.pending === 'falsify' ? 'What evidence would change your mind?' : 'Is anything still unresolved before you reflect?';
    out.technique_id = out.pending === 'counter' ? 'nickerson1998' : 'lord1984';
    if (level === 1 && out.pending === 'counter') out.hint = 'Start with: "They\'d probably say…"';
  } else if (task === 'reflect_open') {
    Object.assign(out, { message: `You started with "${position}".`, question: 'Has your view changed — and why, or why not?', technique_id: 'flavell1979' });
  }
  // test hook: lets the integration test check the anti-hallucination layer end to end
  if (latest.includes('[[test:unsupported-claim]]')) out.message += ' Studies show that 73% of students regret switching topics.';
  return out;
}

function socratic(input, level) {
  const assumption = field(input, 'assumption');
  const position = field(input, 'position');
  const qs = [
    { question: assumption ? 'How do you know your assumption actually holds?' : 'What does your view depend on?', type: 'assumption', targets_quote: assumption || null, critic: level === 4 ? 'Domain expert' : null },
    { question: 'What is the strongest argument against your position?', type: 'alternative', targets_quote: position || null, critic: level === 4 ? 'Sceptical reviewer' : null },
    { question: 'If this turned out to be the wrong choice, what would be the most likely reason?', type: 'consequence', targets_quote: null, critic: level === 4 ? 'Premortem' : null },
  ];
  return { intro: level >= 3 ? 'Here is where your case is weakest.' : 'Three questions to test your view.', questions: qs, technique_id: level === 4 ? 'klein2007' : 'lord1984', safety_concern: false };
}

function bias(input) {
  const text = field(input, 'reasoning');
  const already = ((/<already_flagged>([^<]*)<\/already_flagged>/.exec(input) || [])[1] || '').split(',').map(s => s.trim());
  const conf = +((/Self-rated confidence: (\d)/.exec(input) || [])[1] || 0);
  const rules = [
    ['appeal_to_authority', /\b(my (supervisor|boss|manager|professor|teacher|parents?|friends?)|experts?|told me)\b/i, 'Your reason leans on someone else’s view rather than the reasoning behind it.'],
    ['bandwagon', /\b(trending|popular|everyone is|hot topic|hype)\b/i, 'Popularity is doing the work in your reason.'],
    ['overgeneralisation', /\b(always|never|everyone|nobody|definitely|obviously)\b/i, 'An absolute word makes this claim easy to break with one counterexample.'],
  ];
  const flags = [];
  for (const [id, re, explanation] of rules) {
    if (already.includes(id)) continue;
    const q = sentenceWith(text, re);
    if (q) flags.push({ bias_id: id, quote: q, explanation, confidence: 'high' });
  }
  if (!flags.length && conf >= 4 && !/\d|data|evidence|study/i.test(text) && !already.includes('overconfidence')) {
    const q = text.split('\n')[0];
    if (wc(q) >= 3) flags.push({ bias_id: 'overconfidence', quote: q, explanation: `You rated your confidence ${conf}/5 without pointing to evidence.`, confidence: 'medium' });
  }
  return { flags: flags.slice(0, 2) };
}

function map(input) {
  const position = field(input, 'position'), reason = field(input, 'main_reason'), assumption = field(input, 'assumption');
  const nodes = [];
  if (reason) nodes.push({ id: 'n1', type: 'assumption', text: short(reason), quote: reason, inferred: false });
  if (assumption) nodes.push({ id: 'n2', type: 'assumption', text: short(assumption), quote: assumption, inferred: false });
  nodes.push({ id: 'n3', type: 'unknown', text: 'What evidence would show this is wrong?', quote: null, inferred: true });
  return { claim: { text: short(position, 80), quote: position }, nodes,
    edges: nodes.map(n => (n.type === 'unknown' ? { from: 'claim', to: n.id, relation: 'depends_on' } : { from: n.id, to: 'claim', relation: 'supports' })) };
}

function reflection(input) {
  const start = field(input, 'position'), end = field(input, 'final_position'), changed = field(input, 'what_changed');
  const same = start.toLowerCase().replace(/\W/g, '') === end.toLowerCase().replace(/\W/g, '');
  const tested = /assumption_named_so_far: yes/.test(input) && /other_side_engaged: yes/.test(input);
  const skill = !/assumption_named_so_far: yes/.test(input) ? 'naming_assumptions' : !/other_side_engaged: yes/.test(input) ? 'considering_other_side' : !/falsifier_stated: yes/.test(input) ? 'stating_falsifiers' : 'none';
  return {
    change_type: same ? (tested ? 'reaffirmed_tested' : 'reaffirmed_untested') : 'revised',
    observation: `You went from "${start}" to "${end}", and said: "${changed}"`,
    message: 'That is your reasoning, tested. The decision stays yours.',
    next_question: 'What will you check first next time you face a decision like this?',
    skill_to_practice: skill,
    practice_prompt: 'Decide whether to renew a subscription you rarely use — write down what your choice depends on before you decide.',
    technique_id: 'flavell1979', safety_concern: false,
  };
}

export function createMockClient({ fail = false, recorder = null } = {}) {
  return {
    messages: {
      async create(req) {
        if (recorder) recorder.push(req);
        if (fail) throw new Error('Mock model unavailable');
        const schema = req.output_config.format.schema;
        const input = req.messages[0].content;
        const level = +((/Level (\d) —/.exec(req.system) || [])[1] || 1);
        const data = schema === COACH_SCHEMA ? coach(input, level)
          : schema === SOCRATIC_SCHEMA ? socratic(input, level)
          : schema === BIAS_SCHEMA ? bias(input)
          : schema === MAP_SCHEMA ? map(input)
          : schema === REFLECTION_SCHEMA ? reflection(input)
          : null;
        if (!data) throw new Error('Unknown schema');
        return { stop_reason: 'end_turn', content: [{ type: 'text', text: JSON.stringify(data) }], usage: { input_tokens: 0, output_tokens: 0 } };
      },
    },
  };
}
