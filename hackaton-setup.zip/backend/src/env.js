// Loads settings from backend/.env (and, as a fallback, a .env in the project root) into process.env.
// Must be the FIRST import in server.js so the AI layer sees the key when it starts.
// Values already set in the real environment win. The key itself is never printed.

import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

export function parseEnv(text) {
  const out = {};
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(line);
    if (!m) continue;
    let value = m[2].trim();
    const quoted = /^(['"])([\s\S]*)\1$/.exec(value);
    if (quoted) value = quoted[2];
    else value = value.replace(/\s+#.*$/, ''); // inline comment after an unquoted value
    out[m[1]] = value;
  }
  return out;
}

export function loadEnv(paths) {
  const loaded = [];
  for (const p of paths) {
    if (!existsSync(p)) continue;
    const vars = parseEnv(readFileSync(p, 'utf8'));
    for (const [k, v] of Object.entries(vars)) if (process.env[k] === undefined || process.env[k] === '') process.env[k] = v;
    loaded.push(p);
  }
  return loaded;
}

export const loadedEnvFiles = loadEnv([
  fileURLToPath(new URL('../.env', import.meta.url)),    // backend/.env
  fileURLToPath(new URL('../../.env', import.meta.url)), // project root .env
]);
