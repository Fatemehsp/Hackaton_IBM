// Minimal reference server for local testing and for Person 3 to copy from.
// No framework needed. Keeps the API key on the server.
//
//   ANTHROPIC_API_KEY=sk-... node examples/dev-server.js path/to/devils-aidvocate.html
//   → open http://localhost:8787
//
// POST /api/respond   body: { session, step, payload }   → result of respond()

import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { respond } from '../src/llm.js';

const PORT = Number(process.env.PORT || 8787);
const htmlPath = process.argv[2];
const MAX_BODY = 200_000; // bytes — sessions are small; refuse anything bigger
const STEPS = new Set(['afterEntry', 'thinkReply', 'openChallenge', 'challengeReply', 'openReflect', 'closing']);

createServer(async (req, res) => {
  const send = (code, body, type = 'application/json') => {
    res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store' });
    res.end(type === 'application/json' ? JSON.stringify(body) : body);
  };
  try {
    if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html') && htmlPath) {
      return send(200, readFileSync(htmlPath, 'utf8'), 'text/html; charset=utf-8');
    }
    if (req.method === 'POST' && req.url === '/api/respond') {
      let raw = '';
      for await (const chunk of req) { raw += chunk; if (raw.length > MAX_BODY) return send(413, { error: 'Request too large' }); }
      const { session, step, payload } = JSON.parse(raw || '{}');
      if (!session || !STEPS.has(step)) return send(400, { error: 'Expected { session, step, payload }' });
      const started = Date.now();
      const result = await respond(session, step, payload || {});
      console.log(`${step} L${session.level} ${Date.now() - started}ms${result.usedFallback ? ' (fallback)' : ''}`);
      return send(200, result);
    }
    send(404, { error: 'Not found' });
  } catch (err) {
    console.error(err);
    // Never leak internals to the browser; the page falls back to its scripted replies.
    send(502, { error: 'The AI service is unavailable right now.' });
  }
}).listen(PORT, () => console.log(`Devil's AIdvocate dev server on http://localhost:${PORT}`));
