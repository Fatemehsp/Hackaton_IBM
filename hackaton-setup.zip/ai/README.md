# Devil's AIdvocate — AI layer (Person 2: AI & Prompt Engineer)

Prompts, Claude API setup, safety guards and tests for the reasoning coach.
It plugs into the existing HTML prototype: every AI reply comes back in the **same shape the prototype already renders** (`html`, `tag`, `bias`, `biasCitation`, `biasQuote`), so the scripted replies can be swapped for live ones without touching the UI.

## Task checklist

| Plan task | Where | Notes |
|---|---|---|
| Level system prompts | `src/prompts.js` → `BASE_SYSTEM`, `LEVEL_PROMPTS` | The plan says L1–L3; the prototype has **4 levels**, so L4 (Stress Test panel) is included. |
| Reasoning Mapper prompt | `MAPPER_SYSTEM`, `src/mermaid.js` | Returns assumptions / feelings / facts / unknowns as JSON; Mermaid code is built in code, never by the model. |
| Bias Detector prompt | `BIAS_SYSTEM`, `src/citations.js` | 12 biases, each tied to a verified reference. Flags need the user's exact words. |
| LLM API setup | `src/llm.js` | Claude Messages API with structured JSON outputs, retries, fallbacks. |
| Socratic Question Generator | `SOCRATIC_TASK` | 2–3 targeted questions (exactly 3 as a panel at Level 4). |
| Reflection Nudge prompt | `REFLECTION_TASK` | Compares start vs end, credits the user's own reasoning, suggests one skill to practise. |
| Test all levels | `test/run-tests.js`, `test/scenarios.js` | 38 offline tests pass. Live run: 6 scenarios × 4 levels with automatic checks and transcripts. |
| Spaced repetition flag | `src/spacedRepetition.js` | Transparent rule decides *whether* to resurface (24 h, 3 days, 1 week); the model only suggests the practice task. |

`PROMPTS.md` contains every prompt, the citation whitelist and all schemas — generated from the code with `npm run docs`.

## Quick start

```bash
npm install
npm test                                    # offline, no API key needed
export ANTHROPIC_API_KEY=sk-ant-...         # server side only
npm run test:live                           # all scenarios × all levels → test-report.md
npm run test:live -- --level=3 --scenario=thesis_topic
node examples/dev-server.js ../devils-aidvocate.html   # http://localhost:8787
```

## How a turn works

```
browser (prototype)                    server (this package)
──────────────────                     ─────────────────────────────────────────────
afterEntry      ── POST /api/respond ─▶ coach "think_open"  ┐
                                        bias detector        ├ in parallel
                                        reasoning mapper     ┘
thinkReply      ─────────────────────▶ coach "think_reply" + bias detector
openChallenge   ─────────────────────▶ mapper + bias detector → Socratic Question Generator
challengeReply  ─────────────────────▶ coach "challenge_reply" + bias detector
openReflect     ─────────────────────▶ coach "reflect_open"
closing         ─────────────────────▶ Reflection Nudge → spaced-repetition flag + 3 review dates
```

Every model output then passes through `src/guards.js` before anything reaches the user.

## Integration contract (for Person 3)

```js
import { respond } from './src/llm.js';
const result = await respond(session, step, payload);
```

- `session` is the prototype's session object as-is (`entry`, `level`, `phase`, `assumption`, `counter`, `falsify`, `flagged`, `messages`, …).
- `step` is named after the prototype function it replaces: `afterEntry`, `thinkReply`, `openChallenge`, `challengeReply`, `openReflect`, `closing`.
- `payload`: `{ text }` for replies; `{ final, clarity, missing }` for `closing`.

The result:

```jsonc
{
  "reply": {
    "html": "You think “I should switch…”<br><br><strong>What has to be true…?</strong>",  // escaped, safe for innerHTML
    "tag": "An argument links a claim to its grounds… (Toulmin, 1958).",                   // “Behind this” line
    "bias": "Argument from authority",                                                    // Requirement 4 fields
    "biasCitation": "Walton, D. (1997). Appeal to Expert Opinion…",
    "biasQuote": "my supervisor seemed interested",
    "state": { "pending": "evidence", "canAdvance": true, "assumption": "This only works if…" },
    "safety": true                                                                        // only when distress is detected
  },
  "newlyFlagged": ["appeal_to_authority"],   // push into session.flagged
  "mermaid": "flowchart TD …",               // afterEntry / openChallenge — for the Reasoning Map view
  "resurface": { "flag": true, "skill": "stating_falsifiers", "reasons": ["…"] },   // closing only
  "reviews": [{ "interval": "24h", "dueAt": "…", "prompt": "…" }, …],              // closing only
  "usedFallback": false,
  "violations": []                           // guard notes, for logging — not for users
}
```

In the prototype, the change is small: inside `aiTurn`, call the server first and keep the scripted reply as the offline fallback.

```js
async function liveReply(s, step, payload) {
  const r = await fetch('/api/respond', { method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ session: s, step, payload }) });
  if (!r.ok) throw new Error('AI unavailable');
  return r.json();
}
// on success: if (res.reply.safety) show the existing safety banner;
//             else push res.reply as the AI message, copy res.reply.state onto s,
//             and add res.newlyFlagged to s.flagged.
// on failure: use the existing scripted function (afterEntry(s), thinkReply(s, text), …).
```

`reply.state` maps the model's evidence-backed signals onto the fields the Clarity Score already reads (`assumption`, `counter`, `falsify`), so the score keeps working unchanged — and now in any language.

## Responsible AI, built in

| Risk | What the code does |
|---|---|
| The AI decides for the user | Rule 1 in every prompt; `findDirectAnswer()` blocks replies like "you should accept", retries once with feedback, then falls back to a safe question. |
| Invented citations | The model can only pick an id from `CITATIONS`; the server inserts the reference text. All 19 references are real published works. |
| Invented evidence | Bias flags, map nodes and Clarity signals must quote the user word-for-word; anything not found in the user's text is dropped. |
| Inferred content looks like fact | Unknowns in the map are always `inferred`; user facts are labelled "stated by you, not verified". |
| Prompt injection | User text is wrapped in `<user_content>` tags, forged tags are stripped, and the prompt says to treat it as data. Tested in the `injection` scenario. |
| Distress | Model-side backstop (`safety_concern`) for wording the keyword check misses; the reply becomes `{ safety: true }` for the existing banner. |
| HTML injection | All model text is escaped in `adapter.js`; the model never writes HTML. |
| Language fairness | Replies in the user's language; Clarity credit is judged from meaning, not English keywords (`german` scenario). |
| Leaked API key | Key only in the server environment; `getClient()` refuses to start without it. |

## Models and settings

| Variable | Default | Used for |
|---|---|---|
| `DA_COACH_MODEL` | `claude-sonnet-5-5` | Conversation, Socratic questions, reflection |
| `DA_FAST_MODEL` | `claude-haiku-5-5` | Bias detector, reasoning mapper |
| `DA_COACH_EFFORT` / `DA_FAST_EFFORT` | `low` | Chat is latency-sensitive; raise to `medium` if quality is too shallow |
| `DA_MAX_TOKENS` | `3000` | Thinking counts toward this limit |

Requests use `output_config.format` (JSON schema) and `output_config.effort`. The first call with each schema is slower while the API compiles it; later calls are cached for 24 hours.

## Known limits

- **Not yet run against the live API** — no key was available while building. Run `npm run test:live` once and **read the transcripts** in `test-report.md`; automated checks can't judge tone or question quality.
- The model is not deterministic: run the live suite more than once before the demo.
- `openChallenge` makes two sequential rounds of calls (map + bias, then questions), so it is the slowest step.
- `looksGerman()` in the tests is a rough check; review the German transcript by eye.
