// LLM API setup (Claude) + one function per AI module.
// Runs on the SERVER only — the API key must never reach the browser.
//
//   respond(session, step, payload)   ← the single entry point Person 3's backend calls
//
// Under the hood:
//   coachTurn          level system prompt + per-turn task
//   socraticQuestions  Socratic Question Generator
//   detectBiases       Bias Detector (fast model)
//   mapReasoning       Reasoning Mapper (fast model) + Mermaid code
//   reflectionNudge    Reflection Nudge + spaced-repetition flag

import Anthropic from '@anthropic-ai/sdk';
import * as P from './prompts.js';
import { COACH_SCHEMA, SOCRATIC_SCHEMA, BIAS_SCHEMA, MAP_SCHEMA, REFLECTION_SCHEMA } from './schemas.js';
import { validate, checkCoach, checkSocratic, checkBiases, checkMap, checkReflection } from './guards.js';
import { coachReply, socraticReply, reflectionReply } from './adapter.js';
import { toMermaid } from './mermaid.js';
import { resurfaceFlag, schedule } from './spacedRepetition.js';

export const CONFIG = {
  coachModel: process.env.DA_COACH_MODEL || 'claude-sonnet-5-5', // speed + intelligence for the conversation
  fastModel: process.env.DA_FAST_MODEL || 'claude-haiku-5-5',    // classification/extraction: bias detector, mapper
  coachEffort: process.env.DA_COACH_EFFORT || 'low',              // chat is latency-sensitive
  fastEffort: process.env.DA_FAST_EFFORT || 'low',
  maxTokens: Number(process.env.DA_MAX_TOKENS || 3000),           // thinking counts toward this, so leave room
  timeoutMs: Number(process.env.DA_TIMEOUT_MS || 45000),
};

export const USAGE = { calls: 0, input_tokens: 0, output_tokens: 0 };

let client = null;
export function getClient() {
  if (!client) {
    if (!process.env.ANTHROPIC_API_KEY) {
      throw new Error('ANTHROPIC_API_KEY is not set. Put it in the server environment — never in the HTML page.');
    }
    client = new Anthropic({ timeout: CONFIG.timeoutMs, maxRetries: 2 }); // SDK retries 429/5xx itself
  }
  return client;
}
/** Inject a client (used by the offline tests). */
export function setClient(c) { client = c; }

export class LLMError extends Error {
  constructor(message, kind) { super(message); this.kind = kind; }
}

/* ───────────── One structured call ───────────── */

async function callJSON({ model, effort, system, input, schema, maxTokens = CONFIG.maxTokens }) {
  let tokens = maxTokens;
  let lastProblem = 'unknown';
  for (let attempt = 1; attempt <= 3; attempt++) {
    const res = await getClient().messages.create({
      model,
      max_tokens: tokens,
      system,
      messages: [{ role: 'user', content: input }],
      output_config: { format: { type: 'json_schema', schema }, effort },
    });
    USAGE.calls++;
    USAGE.input_tokens += res.usage?.input_tokens || 0;
    USAGE.output_tokens += res.usage?.output_tokens || 0;

    if (res.stop_reason === 'refusal') throw new LLMError('The model declined this request.', 'refusal');
    if (res.stop_reason === 'max_tokens') { tokens *= 2; lastProblem = 'truncated'; continue; }

    const text = res.content.filter(b => b.type === 'text').map(b => b.text).join('');
    let data;
    try { data = JSON.parse(text); } catch { lastProblem = 'invalid JSON'; continue; }
    const errs = validate(schema, data);
    if (errs.length) { lastProblem = `schema mismatch (${errs[0]})`; continue; }
    return data;
  }
  throw new LLMError(`No usable output after 3 attempts: ${lastProblem}`, 'output');
}

/* ───────────── Call + rule checks + one corrective retry ───────────── */

async function guarded({ call, input, check, ctx, fallback }) {
  let data = await callJSON({ ...call, input });
  let r = check(data, ctx);
  if (r.blocking.length) {
    const retry = `${input}\n\nYour previous answer broke these rules: ${r.blocking.join('; ')}. Write a corrected answer that follows every rule.`;
    data = await callJSON({ ...call, input: retry });
    const r2 = check(data, ctx);
    if (r2.blocking.length) return { out: fallback ? fallback(r2.out) : r2.out, violations: r2.violations, fallback: true };
    return { out: r2.out, violations: [`retried: ${r.blocking.join('; ')}`, ...r2.violations], fallback: false };
  }
  return { out: r.out, violations: r.violations, fallback: false };
}

/** Every piece of text the user wrote in this session (for verbatim-quote checks). */
export function userTexts(session, latest) {
  const e = session.entry || {};
  return [e.question, e.position, e.reason, session.assumption, latest,
    ...(session.messages || []).filter(m => m.type === 'user').map(m => m.text)].filter(Boolean);
}

/* ───────────── Modules ───────────── */

const FALLBACK_QUESTION = {
  think_open: 'What has to be true for your reason to support your view?',
  think_reply: 'What does your reasoning depend on?',
  challenge_reply: 'What is the strongest point against your view?',
  reflect_open: 'Has your view changed — and why, or why not?',
};

export function coachTurn(session, task, latest = null, research = []) {
  const level = session.level || 1;
  return guarded({
    call: { model: CONFIG.coachModel, effort: CONFIG.coachEffort, system: P.coachSystem(level), schema: COACH_SCHEMA },
    input: P.coachInput(session, task, latest, research),
    check: checkCoach,
    ctx: { level, userTexts: userTexts(session, latest) },
    fallback: out => ({ ...out, message: '', question: FALLBACK_QUESTION[task], panel: [], hint: null }),
  });
}

export function socraticQuestions(session, map, flags, research = []) {
  const level = session.level || 1;
  return guarded({
    call: { model: CONFIG.coachModel, effort: CONFIG.coachEffort, system: P.coachSystem(level), schema: SOCRATIC_SCHEMA },
    input: P.socraticInput(session, map, flags, research),
    check: checkSocratic,
    ctx: { level, userTexts: userTexts(session) },
    fallback: out => ({
      ...out,
      intro: 'Three questions to test your view.',
      questions: [
        { question: 'How do you know the assumption behind your view is true?', type: 'assumption', targets_quote: null, critic: level === 4 ? 'Domain expert' : null },
        { question: 'What is the strongest argument against your position?', type: 'alternative', targets_quote: null, critic: level === 4 ? 'Sceptical reviewer' : null },
        { question: 'If this turned out to be the wrong choice, what would be the most likely reason?', type: 'consequence', targets_quote: null, critic: level === 4 ? 'Premortem' : null },
      ],
    }),
  });
}

export async function detectBiases(session, text, confidence = null) {
  const alreadyFlagged = session.flagged || [];
  const data = await callJSON({
    model: CONFIG.fastModel, effort: CONFIG.fastEffort, system: P.BIAS_SYSTEM, schema: BIAS_SCHEMA,
    input: P.biasInput(text, alreadyFlagged, confidence),
    maxTokens: 1500,
  });
  const r = checkBiases(data, { userTexts: [text], alreadyFlagged });
  return { flags: r.out.flags, violations: r.violations };
}

export async function mapReasoning(session) {
  const data = await callJSON({
    model: CONFIG.fastModel, effort: CONFIG.fastEffort, system: P.MAPPER_SYSTEM, schema: MAP_SCHEMA,
    input: P.mapperInput(session),
    maxTokens: 2000,
  });
  const r = checkMap(data, { userTexts: userTexts(session) });
  return { map: r.out, mermaid: toMermaid(r.out), violations: r.violations };
}

export function reflectionNudge(session, final, research = []) {
  return guarded({
    call: { model: CONFIG.coachModel, effort: CONFIG.coachEffort, system: P.coachSystem(session.level || 1), schema: REFLECTION_SCHEMA },
    input: P.reflectionInput(session, final, research),
    check: checkReflection,
    ctx: {},
    fallback: out => ({ ...out, next_question: 'What will you check first next time you face a decision like this?' }),
  });
}

/* ───────────── Entry point for the backend ───────────── */

/**
 * @param {object} session  the prototype's session object (entry, level, phase, assumption, counter, falsify, flagged, messages…)
 * @param {'afterEntry'|'thinkReply'|'openChallenge'|'challengeReply'|'openReflect'|'closing'} step
 *        named after the functions in the HTML prototype they replace
 * @param {object} payload  { text } for replies; { final, clarity, missing } for closing
 * @param {object} [options] { research: [{ id, finding }] } — retrieved notes from the backend's RAG step
 * @returns {Promise<object>} { reply, map?, mermaid?, resurface?, reviews?, newlyFlagged, violations }
 *          reply has the shape the prototype renders: { html, tag, bias, biasCitation, biasQuote, state, safety? }
 */
export async function respond(session, step, payload = {}, options = {}) {
  const research = options.research || [];
  const s = session;
  const e = s.entry || {};
  const safeMap = () => mapReasoning(s).catch(err => ({ map: null, mermaid: null, violations: [`mapper failed: ${err.message}`] }));
  const safeBias = (text, conf) => detectBiases(s, text, conf).catch(err => ({ flags: [], violations: [`bias detector failed: ${err.message}`] }));
  const result = (reply, parts) => ({
    reply,
    newlyFlagged: reply.biasId ? [reply.biasId] : [],
    usedFallback: parts.some(p => p && p.fallback),
    model: CONFIG.coachModel,
    violations: parts.flatMap(p => (p && p.violations) || []),
  });

  switch (step) {
    case 'afterEntry': {
      const [coach, bias, map] = await Promise.all([
        coachTurn(s, 'think_open', null, research),
        safeBias(`${e.position}\n${e.reason}`, e.confidence),
        safeMap(),
      ]);
      return { ...result(coachReply(coach.out, bias.flags), [coach, bias, map]), map: map.map, mermaid: map.mermaid };
    }
    case 'thinkReply': {
      const [coach, bias] = await Promise.all([coachTurn(s, 'think_reply', payload.text, research), safeBias(payload.text)]);
      return result(coachReply(coach.out, bias.flags), [coach, bias]);
    }
    case 'openChallenge': {
      const [map, bias] = await Promise.all([safeMap(), safeBias([e.position, e.reason, s.assumption || ''].join('\n'), e.confidence)]);
      const soc = await socraticQuestions(s, map.map, bias.flags, research);
      return { ...result(socraticReply(soc.out, bias.flags), [map, bias, soc]), map: map.map, mermaid: map.mermaid };
    }
    case 'challengeReply': {
      const [coach, bias] = await Promise.all([coachTurn(s, 'challenge_reply', payload.text, research), safeBias(payload.text)]);
      return result(coachReply(coach.out, bias.flags), [coach, bias]);
    }
    case 'openReflect': {
      const coach = await coachTurn(s, 'reflect_open', null, research);
      return result(coachReply(coach.out), [coach]);
    }
    case 'closing': {
      const r = await reflectionNudge(s, payload.final, research);
      const reply = reflectionReply(r.out);
      const flag = resurfaceFlag({
        clarity: payload.clarity ?? 0,
        missing: payload.missing || [],
        changeType: r.out.change_type,
        biasesFlagged: (s.flagged || []).length,
        suggestedSkill: r.out.skill_to_practice,
        confidenceBefore: e.confidence,
        confidenceAfter: payload.final?.confidence,
      });
      return { ...result(reply, [r]), resurface: flag, reviews: schedule(s.id, flag, r.out.practice_prompt) };
    }
    default:
      throw new Error(`Unknown step: ${step}`);
  }
}
