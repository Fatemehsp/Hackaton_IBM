// Verified reference whitelist — the ONLY citations the app may show.
// The model never writes a reference itself: it picks an id from this list, and the server
// looks up the text here. This is what keeps the promise "the tool will never invent a citation".
// Every entry below is a real, published work.

export const CITATIONS = {
  toulmin1958: {
    label: 'Toulmin (1958)',
    behind: 'An argument links a claim to its grounds through an often unstated warrant (Toulmin, 1958).',
    reference: 'Toulmin, S. E. (1958). The Uses of Argument. Cambridge University Press.',
  },
  lord1984: {
    label: 'Lord, Lepper & Preston (1984)',
    behind: 'Deliberately considering the opposite reduces biased judgement (Lord, Lepper & Preston, 1984).',
    reference: 'Lord, C. G., Lepper, M. R., & Preston, E. (1984). Considering the opposite: A corrective strategy for social judgment. Journal of Personality and Social Psychology, 47(6), 1231–1243.',
  },
  nickerson1998: {
    label: 'Nickerson (1998)',
    behind: 'Confirmation bias: favouring evidence that fits what we already believe (Nickerson, 1998).',
    reference: 'Nickerson, R. S. (1998). Confirmation bias: A ubiquitous phenomenon in many guises. Review of General Psychology, 2(2), 175–220.',
  },
  moore2008: {
    label: 'Moore & Healy (2008)',
    behind: 'Overconfidence: certainty that outruns the evidence (Moore & Healy, 2008).',
    reference: 'Moore, D. A., & Healy, P. J. (2008). The trouble with overconfidence. Psychological Review, 115(2), 502–517.',
  },
  walton1997: {
    label: 'Walton (1997)',
    behind: "Argument from authority: someone's status or opinion is not evidence by itself (Walton, 1997).",
    reference: 'Walton, D. (1997). Appeal to Expert Opinion: Arguments from Authority. Pennsylvania State University Press.',
  },
  leibenstein1950: {
    label: 'Leibenstein (1950)',
    behind: 'Bandwagon effect: popularity is not evidence of merit (Leibenstein, 1950).',
    reference: "Leibenstein, H. (1950). Bandwagon, snob, and Veblen effects in the theory of consumers' demand. Quarterly Journal of Economics, 64(2), 183–207.",
  },
  popper1959: {
    label: 'Popper (1959)',
    behind: 'A universal claim can be refuted by a single counterexample (Popper, 1959).',
    reference: 'Popper, K. (1959). The Logic of Scientific Discovery. Hutchinson.',
  },
  kunda1990: {
    label: 'Kunda (1990)',
    behind: 'Motivated reasoning: reaching the conclusion we want, then justifying it (Kunda, 1990).',
    reference: 'Kunda, Z. (1990). The case for motivated reasoning. Psychological Bulletin, 108(3), 480–498.',
  },
  klein2007: {
    label: 'Klein (2007)',
    behind: 'Premortem: imagine the plan has failed, then explain why (Klein, 2007).',
    reference: 'Klein, G. (2007). Performing a project premortem. Harvard Business Review, 85(9), 18–19.',
  },
  flavell1979: {
    label: 'Flavell (1979)',
    behind: 'Metacognition: monitoring and evaluating your own thinking (Flavell, 1979).',
    reference: 'Flavell, J. H. (1979). Metacognition and cognitive monitoring: A new area of cognitive–developmental inquiry. American Psychologist, 34(10), 906–911.',
  },
  tversky1973: {
    label: 'Tversky & Kahneman (1973)',
    behind: 'Availability heuristic: judging how likely something is by how easily examples come to mind (Tversky & Kahneman, 1973).',
    reference: 'Tversky, A., & Kahneman, D. (1973). Availability: A heuristic for judging frequency and probability. Cognitive Psychology, 5(2), 207–232.',
  },
  tversky1974: {
    label: 'Tversky & Kahneman (1974)',
    behind: 'Anchoring: an initial number or reference point pulls later judgements towards it (Tversky & Kahneman, 1974).',
    reference: 'Tversky, A., & Kahneman, D. (1974). Judgment under uncertainty: Heuristics and biases. Science, 185(4157), 1124–1131.',
  },
  kahneman2011: {
    label: 'Kahneman (2011)',
    behind: 'Fast, intuitive thinking (System 1) often answers before slow, deliberate thinking (System 2) checks it (Kahneman, 2011).',
    reference: 'Kahneman, D. (2011). Thinking, Fast and Slow. Farrar, Straus and Giroux.',
  },
  arkes1985: {
    label: 'Arkes & Blumer (1985)',
    behind: 'Sunk cost effect: continuing because of what has already been invested (Arkes & Blumer, 1985).',
    reference: 'Arkes, H. R., & Blumer, C. (1985). The psychology of sunk cost. Organizational Behavior and Human Decision Processes, 35(1), 124–140.',
  },
  samuelson1988: {
    label: 'Samuelson & Zeckhauser (1988)',
    behind: 'Status quo bias: preferring the current state simply because it is current (Samuelson & Zeckhauser, 1988).',
    reference: 'Samuelson, W., & Zeckhauser, R. (1988). Status quo bias in decision making. Journal of Risk and Uncertainty, 1(1), 7–59.',
  },
  slovic2007: {
    label: 'Slovic et al. (2007)',
    behind: 'Affect heuristic: letting feelings stand in for evidence about risks and benefits (Slovic et al., 2007).',
    reference: 'Slovic, P., Finucane, M. L., Peters, E., & MacGregor, D. G. (2007). The affect heuristic. European Journal of Operational Research, 177(3), 1333–1352.',
  },
  parasuraman2010: {
    label: 'Parasuraman & Manzey (2010)',
    behind: 'Automation bias: trusting an automated system’s output without checking it (Parasuraman & Manzey, 2010).',
    reference: 'Parasuraman, R., & Manzey, D. H. (2010). Complacency and bias in human use of automation: An attentional integration. Human Factors, 52(3), 381–410.',
  },
  ebbinghaus1885: {
    label: 'Ebbinghaus (1885)',
    behind: 'Spaced repetition: memories fade fast unless revisited at increasing intervals (Ebbinghaus, 1885).',
    reference: 'Ebbinghaus, H. (1885/1913). Memory: A Contribution to Experimental Psychology (H. A. Ruger & C. E. Bussenius, Trans.). Teachers College, Columbia University.',
  },
  bucinca2021: {
    label: 'Buçinca, Malaya & Gajos (2021)',
    behind: 'Asking people to commit before they see AI input reduces over-reliance on it (Buçinca, Malaya & Gajos, 2021).',
    reference: 'Buçinca, Z., Malaya, M. B., & Gajos, K. Z. (2021). To trust or to think: Cognitive forcing functions can reduce overreliance on AI in AI-assisted decision-making. Proceedings of the ACM on Human-Computer Interaction, 5(CSCW1), Article 188.',
  },
};

export const CITATION_IDS = Object.keys(CITATIONS);

// Biases the detector may flag. Each one points to a whitelisted citation.
export const BIASES = {
  confirmation_bias:      { name: 'Confirmation bias',        cite: 'nickerson1998',
    lookFor: 'Only citing points that support their view; dismissing or ignoring obvious counterpoints; restating the position instead of testing it.',
    notWhen: 'They simply hold a view, or mention a supporting reason once. Having a position is not a bias.' },
  availability_heuristic: { name: 'Availability heuristic',   cite: 'tversky1973',
    lookFor: 'Judging how likely or common something is from one vivid, recent or personal example ("my friend did it and it worked", "I saw a news story").',
    notWhen: 'The example is offered as one data point among others, or they acknowledge it may not generalise.' },
  anchoring:              { name: 'Anchoring',                cite: 'tversky1974',
    lookFor: 'A first number, offer or reference point dominating the judgement ("they offered 50k so anything less is bad").',
    notWhen: 'A number is mentioned without driving the conclusion.' },
  overconfidence:         { name: 'Overconfidence',           cite: 'moore2008',
    lookFor: 'Certainty clearly beyond the evidence given: confidence 4–5 out of 5 with no evidence, or words like "definitely", "obviously", "guaranteed" about uncertain outcomes.',
    notWhen: 'They give evidence that plausibly supports their confidence.' },
  appeal_to_authority:    { name: 'Argument from authority',  cite: 'walton1997',
    lookFor: 'Treating someone’s status or opinion as the reason ("my supervisor thinks so", "experts say") without the reasoning behind it.',
    notWhen: 'They explain the expert’s reasoning or evidence, or the person is merely mentioned.' },
  bandwagon:              { name: 'Bandwagon effect',         cite: 'leibenstein1950',
    lookFor: 'Popularity as the reason: "everyone is doing it", "it’s trending", "it’s the hot topic".',
    notWhen: 'Popularity is relevant to the goal itself (e.g. they want a topic with many collaborators) and they say so.' },
  overgeneralisation:     { name: 'Overgeneralisation',       cite: 'popper1959',
    lookFor: 'Universal claims from limited cases: always, never, everyone, nobody, all, none.',
    notWhen: 'The absolute word is a figure of speech that does not carry the argument.' },
  sunk_cost:              { name: 'Sunk cost effect',         cite: 'arkes1985',
    lookFor: 'Continuing because of time, money or effort already spent ("I’ve already put two years into it").',
    notWhen: 'Past investment is mentioned as context, not as the reason to continue.' },
  status_quo_bias:        { name: 'Status quo bias',          cite: 'samuelson1988',
    lookFor: 'Preferring the current option mainly because it is current or familiar.',
    notWhen: 'They give concrete reasons the current option is better.' },
  affect_heuristic:       { name: 'Affect heuristic',         cite: 'slovic2007',
    lookFor: 'A feeling (excitement, fear, dread) used as if it were evidence about outcomes ("it just feels right so it must be the best choice").',
    notWhen: 'They mention feelings as one input and treat them as feelings. Emotions are valid information; only flag when they replace evidence.' },
  automation_bias:        { name: 'Automation bias',          cite: 'parasuraman2010',
    lookFor: 'Accepting an AI, app or tool output as correct without checking ("ChatGPT said so", "the calculator says it’s fine").',
    notWhen: 'They describe checking or questioning the tool’s output.' },
  motivated_reasoning:    { name: 'Motivated reasoning',      cite: 'kunda1990',
    lookFor: 'Reasoning backwards from a wanted conclusion: moving the goalposts, explaining away every counterpoint, refusing to name anything that would change their mind.',
    notWhen: 'They concede points or say what evidence would change their mind.' },
};

export const BIAS_IDS = Object.keys(BIASES);

/** Look up a citation; returns null for anything not on the whitelist. */
export function citation(id) {
  return id && Object.prototype.hasOwnProperty.call(CITATIONS, id) ? CITATIONS[id] : null;
}
