// Spaced repetition flag (24 h, 3 days, 1 week — after Ebbinghaus, 1885).
// The DECISION to resurface is a transparent rule; the model only suggests which skill to
// practise and writes the practice prompt (Reflection Nudge).

export const INTERVALS = [
  { key: '24h', days: 1 },
  { key: '3d', days: 3 },
  { key: '1w', days: 7 },
];

export const SKILL_LABELS = {
  naming_assumptions: 'naming the assumption behind your view',
  considering_other_side: 'weighing the other side',
  stating_falsifiers: 'saying what would change your mind',
  separating_evidence_from_opinion: 'separating evidence from opinion',
  calibrating_confidence: 'matching your confidence to your evidence',
};

// Clarity Score items (same keys as the HTML prototype's rubric) → skill to practise
const RUBRIC_TO_SKILL = {
  assumption: 'naming_assumptions',
  counter: 'considering_other_side',
  falsify: 'stating_falsifiers',
  explained: 'separating_evidence_from_opinion',
};

/**
 * Decide whether this session should come back later.
 * @param {object} p
 * @param {number} p.clarity          Clarity Score 0–100
 * @param {string[]} p.missing        rubric keys not achieved (e.g. ['falsify'])
 * @param {string} p.changeType       from the Reflection Nudge
 * @param {number} p.biasesFlagged    number of bias flags shown this session
 * @param {string} p.suggestedSkill   skill_to_practice from the Reflection Nudge
 * @param {number} p.confidenceBefore 1–5
 * @param {number} p.confidenceAfter  1–5
 */
export function resurfaceFlag({ clarity, missing = [], changeType, biasesFlagged = 0, suggestedSkill, confidenceBefore, confidenceAfter }) {
  const reasons = [];
  if (clarity < 100) reasons.push(`Clarity Score ${clarity}% (missing: ${missing.join(', ') || 'none'})`);
  if (changeType === 'reaffirmed_untested') reasons.push('view kept without being tested');
  if (biasesFlagged > 0) reasons.push(`${biasesFlagged} bias flag(s)`);
  if (confidenceAfter === 5 && changeType !== 'revised' && missing.length) reasons.push('maximum confidence with gaps in reasoning');

  let skill = suggestedSkill && suggestedSkill !== 'none' ? suggestedSkill : null;
  if (!skill && missing.length) skill = RUBRIC_TO_SKILL[missing.find(k => RUBRIC_TO_SKILL[k])] || null;
  if (!skill && reasons.length && confidenceBefore >= 4 && confidenceAfter >= 4) skill = 'calibrating_confidence';

  return { flag: reasons.length > 0, skill, reasons };
}

/** Build the three review dates for a flagged session. */
export function schedule(sessionId, flag, practicePrompt, completedAt = new Date()) {
  if (!flag.flag) return [];
  const base = new Date(completedAt).getTime();
  return INTERVALS.map(({ key, days }) => ({
    sessionId,
    interval: key,
    dueAt: new Date(base + days * 864e5).toISOString(),
    skill: flag.skill,
    prompt: practicePrompt,
    done: false,
  }));
}

/** Challenges that are due now (oldest first). */
export function dueChallenges(items, now = new Date()) {
  const t = new Date(now).getTime();
  return items.filter(i => !i.done && new Date(i.dueAt).getTime() <= t).sort((a, b) => a.dueAt.localeCompare(b.dueAt));
}

/** Text for the resurfacing card. */
export function nudgeText(item) {
  const skill = SKILL_LABELS[item.skill] || 'thinking it through on your own';
  return `Last time, ${skill} was the hard part. Try this one alone — no AI: ${item.prompt}`;
}
