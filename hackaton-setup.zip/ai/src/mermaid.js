// Turns the Reasoning Mapper's JSON into Mermaid flowchart code for Person 1's map view.
// Built deterministically here (not by the model), so the syntax is always valid and
// user text can't inject Mermaid or HTML.

const LABEL = { assumption: 'Assumption', emotion: 'Feeling', fact: 'Fact (stated by you, not verified)', unknown: 'Unknown (inferred, check it)' };

/** Escape text for a quoted Mermaid label. */
export function mermaidText(s, max = 90) {
  let t = String(s ?? '').replace(/\s+/g, ' ').trim();
  if (t.length > max) t = t.slice(0, max - 1).trimEnd() + '…';
  // Swap the few characters that can break a quoted label for safe lookalikes.
  // (Mermaid's #quot; style codes are not decoded by every renderer version.)
  return t
    .replace(/"/g, '’')
    .replace(/</g, '‹')
    .replace(/>/g, '›')
    .replace(/#/g, '＃')
    .replace(/`/g, "'");
}

export function toMermaid(map) {
  const lines = ['flowchart TD'];
  lines.push(`  claim(["Your position: ${mermaidText(map.claim.text)}"]):::claim`);
  for (const n of map.nodes) {
    const label = `${LABEL[n.type]}: ${mermaidText(n.text)}`;
    const shape = n.type === 'unknown' ? `{{"${label}"}}`
      : n.type === 'emotion' ? `(["${label}"])`
      : `["${label}"]`;
    lines.push(`  ${n.id}${shape}:::${n.type}`);
  }
  for (const e of map.edges) {
    const arrow = e.relation === 'supports' ? '-->|supports|'
      : e.relation === 'depends_on' ? '-.->|depends on|'
      : '==>|contradicts|';
    lines.push(`  ${e.from} ${arrow} ${e.to}`);
  }
  lines.push(
    '  classDef claim fill:#4a7c6f,color:#ffffff,stroke:#3c695d,stroke-width:2px',
    '  classDef assumption fill:#e2eeea,color:#1f3a33,stroke:#3f6e62',
    '  classDef emotion fill:#fbe8df,color:#5a2a17,stroke:#9a4a2b',
    '  classDef fact fill:#e7ebf7,color:#28345a,stroke:#4a5c92',
    '  classDef unknown fill:#ffffff,color:#2a2a2a,stroke:#8a877d,stroke-dasharray:5 4',
  );
  return lines.join('\n');
}
