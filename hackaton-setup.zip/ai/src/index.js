// Public API of the Person 2 AI layer.
export { respond, coachTurn, socraticQuestions, detectBiases, mapReasoning, reflectionNudge, CONFIG, USAGE, setClient } from './llm.js';
export { toMermaid } from './mermaid.js';
export { resurfaceFlag, schedule, dueChallenges, nudgeText } from './spacedRepetition.js';
export { CITATIONS, BIASES } from './citations.js';
export * as prompts from './prompts.js';
