// Converts model output into the reply object the HTML prototype already renders:
//   { html, tag, bias, biasCitation, biasQuote, gained? }  (see msgEl / aiTurn in the HTML)
// plus state updates for the session (pending, canAdvance, Clarity signals, safety).
// Model text is always escaped here — the model never writes HTML.

import { citation, BIASES, CITATIONS } from './citations.js';

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const hintText = h => (/^\s*hint\b/i.test(h) ? h : `Hint: ${h}`);

function behind(id) {
  const c = citation(id);
  return c ? c.behind : null;
}

/** First new bias flag → the three fields Requirement 4 renders. */
export function biasFields(flags) {
  const f = flags && flags[0];
  if (!f) return {};
  const b = BIASES[f.bias_id];
  return {
    bias: b.name,
    biasCitation: CITATIONS[b.cite].reference,
    biasQuote: f.quote,
    biasExplanation: f.explanation,
    biasId: f.bias_id,
    biasConfidence: f.confidence,
    biasCiteId: b.cite,
  };
}

/** Coach turn (think_open, think_reply, challenge_reply, reflect_open). */
export function coachReply(out, flags = []) {
  if (out.safety_concern) return { safety: true, html: esc(out.message), tag: null };
  let html;
  if (out.panel && out.panel.length) {
    html = `${out.message ? `<p>${esc(out.message)}</p>` : ''}<ol class="panel">${out.panel
      .map(p => `<li><b>${esc(p.critic)}:</b> ${esc(p.objection)}</li>`).join('')}</ol>${out.question ? `<p><strong>${esc(out.question)}</strong></p>` : ''}`;
  } else {
    html = `${esc(out.message)}${out.question ? `${out.message ? '<br><br>' : ''}<strong>${esc(out.question)}</strong>` : ''}`;
  }
  if (out.hint) html += `<span class="hint">${esc(hintText(out.hint))}</span>`;
  return {
    html,
    tag: behind(out.technique_id),
    techniqueId: citation(out.technique_id) ? out.technique_id : null,
    ...biasFields(flags),
    state: stateFromSignals(out),
  };
}

/** Socratic Question Generator → opening of the Challenge step. */
export function socraticReply(out, flags = []) {
  if (out.safety_concern) return { safety: true, html: esc(out.intro), tag: null };
  const items = out.questions.map(q => `<li>${q.critic ? `<b>${esc(q.critic)}:</b> ` : ''}${esc(q.question)}</li>`).join('');
  return {
    html: `<p>${esc(out.intro)}</p><ol class="panel">${items}</ol>`,
    tag: behind(out.technique_id),
    techniqueId: citation(out.technique_id) ? out.technique_id : null,
    ...biasFields(flags),
    state: { pending: 'counter', canAdvance: false },
  };
}

/** Reflection Nudge → closing message (+ data for the summary card and spaced repetition). */
export function reflectionReply(out) {
  if (out.safety_concern) return { safety: true, html: esc(out.message), tag: null };
  return {
    html: `${esc(out.observation)}<br><br>${esc(out.message)}<br><br><strong>${esc(out.next_question)}</strong>`,
    tag: behind(out.technique_id),
    techniqueId: citation(out.technique_id) ? out.technique_id : null,
    reflection: {
      changeType: out.change_type,
      skill: out.skill_to_practice,
      practicePrompt: out.practice_prompt,
    },
  };
}

/** Map the model's evidence-backed signals onto the prototype's Clarity Score fields. */
export function stateFromSignals(out) {
  const s = out.signals || {};
  const state = {
    pending: out.pending === 'none' ? null : out.pending,
    canAdvance: !!out.can_advance,
  };
  if (s.named_assumption?.present) state.assumption = s.named_assumption.quote;
  if (s.engaged_other_side?.present) { state.counter = true; state.counterText = s.engaged_other_side.quote; }
  if (s.stated_falsifier?.present) state.falsify = s.stated_falsifier.quote;
  return state;
}
