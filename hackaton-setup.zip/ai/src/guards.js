// Guards: everything we check AFTER the model answers.
// Structured outputs guarantee the JSON shape; these checks enforce the rules a schema can't:
// verbatim quotes (anti-hallucination), no direct answers, question counts, level rules.

import { BIASES } from './citations.js';

/* ───────────── Text helpers ───────────── */

export function normalize(s) {
  return String(s ?? '')
    .toLowerCase()
    .replace(/[’‘`´]/g, "'")
    .replace(/[“”„«»]/g, '"')
    .replace(/\s+/g, ' ')
    .trim();
}

/** True if `quote` appears word-for-word (ignoring case, spacing and quote style) in any source text. */
export function isVerbatim(quote, sources) {
  const q = normalize(quote).replace(/^["'\s]+|["'\s.,;:!?…]+$/g, '');
  if (q.length < 3) return false;
  return sources.some(src => normalize(src).includes(q));
}

const DIRECT_ANSWER = [
  /\byou should (accept|take|choose|go with|pick|do it|switch|stay|quit|reject|decline|leave|buy|sell|move|stop|start)\b/i,
  /\byou shouldn'?t (accept|take|choose|go with|pick|do it|switch|stay|quit|reject|decline|leave)\b/i,
  /\bI(?:'d| would)? recommend\b/i,
  /\bmy (advice|recommendation|verdict) is\b/i,
  /\bthe (right|best|correct|smart) (choice|answer|option|decision|move) is\b/i,
  /\bI suggest (that )?you\b/i,
  /\bif I were you\b/i,
  /\bI(?:'d| would) (go with|choose|pick|take|accept)\b/i,
  /\bthe answer is\b/i,
];

/** Returns the offending phrase if the text recommends or decides for the user, else null. */
export function findDirectAnswer(text) {
  for (const re of DIRECT_ANSWER) {
    const m = re.exec(String(text ?? ''));
    if (m) return m[0];
  }
  return null;
}

const LEADING = /\b(don'?t you think|wouldn'?t you agree|isn'?t it (true|obvious|clear)|surely you)\b/i;
export const isLeading = text => LEADING.test(String(text ?? ''));

/* ───────────── Minimal JSON-schema validator (for the subset we use) ───────────── */

export function validate(schema, value, path = '$') {
  const errs = [];
  if (schema.anyOf) {
    if (!schema.anyOf.some(s => validate(s, value, path).length === 0)) errs.push(`${path}: matches no allowed type`);
    return errs;
  }
  const t = schema.type;
  if (t === 'null' && value !== null) errs.push(`${path}: expected null`);
  if (t === 'string' && typeof value !== 'string') errs.push(`${path}: expected string`);
  if (t === 'boolean' && typeof value !== 'boolean') errs.push(`${path}: expected boolean`);
  if (t === 'number' && typeof value !== 'number') errs.push(`${path}: expected number`);
  if (t === 'integer' && !Number.isInteger(value)) errs.push(`${path}: expected integer`);
  if (schema.enum && !schema.enum.includes(value)) errs.push(`${path}: "${value}" not in enum`);
  if (t === 'array') {
    if (!Array.isArray(value)) errs.push(`${path}: expected array`);
    else value.forEach((v, i) => errs.push(...validate(schema.items, v, `${path}[${i}]`)));
  }
  if (t === 'object') {
    if (!value || typeof value !== 'object' || Array.isArray(value)) { errs.push(`${path}: expected object`); return errs; }
    for (const k of schema.required || []) if (!(k in value)) errs.push(`${path}.${k}: missing`);
    if (schema.additionalProperties === false) for (const k of Object.keys(value)) if (!(k in schema.properties)) errs.push(`${path}.${k}: not allowed`);
    for (const [k, s] of Object.entries(schema.properties || {})) if (k in value) errs.push(...validate(s, value[k], `${path}.${k}`));
  }
  return errs;
}

/** Checks a schema only uses features the structured-outputs API accepts. */
export function checkSchemaCompat(schema, path = '$') {
  const errs = [];
  const banned = ['minLength', 'maxLength', 'minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum', 'multipleOf', 'maxItems', 'pattern'];
  for (const k of banned) if (k in schema) errs.push(`${path}: uses unsupported "${k}"`);
  if ('minItems' in schema && schema.minItems > 1) errs.push(`${path}: minItems > 1 unsupported`);
  if (schema.anyOf) schema.anyOf.forEach((s, i) => errs.push(...checkSchemaCompat(s, `${path}.anyOf[${i}]`)));
  if (schema.type === 'object') {
    if (schema.additionalProperties !== false) errs.push(`${path}: additionalProperties must be false`);
    const props = Object.keys(schema.properties || {});
    const missing = props.filter(p => !(schema.required || []).includes(p));
    if (missing.length) errs.push(`${path}: not required: ${missing.join(', ')}`);
    for (const [k, s] of Object.entries(schema.properties || {})) errs.push(...checkSchemaCompat(s, `${path}.${k}`));
  }
  if (schema.type === 'array' && schema.items) errs.push(...checkSchemaCompat(schema.items, `${path}[]`));
  return errs;
}

/* ───────────── Post-processing per output type ───────────── */

/** Coach turn: drop un-evidenced signals, enforce level rules, report rule breaks. */
export function checkCoach(out, { level, userTexts }) {
  const violations = [];
  const o = structuredClone(out);
  for (const [key, sig] of Object.entries(o.signals)) {
    if (sig.present && !isVerbatim(sig.quote, userTexts)) { sig.present = false; sig.quote = null; violations.push(`signal ${key}: quote not found in user text (credit removed)`); }
    if (!sig.present) sig.quote = null;
  }
  if (level !== 4) o.panel = [];
  if (level >= 3 && o.hint) o.hint = null;
  const visible = [o.message, o.question, ...o.panel.map(p => p.objection)].join(' ');
  const direct = findDirectAnswer(visible);
  if (direct) violations.push(`direct answer: "${direct}"`);
  if (!o.safety_concern && o.question && !o.question.trim().endsWith('?')) violations.push('question does not end with "?"');
  if (o.safety_concern) { o.question = ''; o.panel = []; o.hint = null; }
  return { out: o, blocking: violations.filter(v => v.startsWith('direct answer') || v.startsWith('question does not')), violations };
}

/** Socratic questions: 2–3 (Level 4: exactly 3), verbatim targets, no leading or answer-giving questions. */
export function checkSocratic(out, { level, userTexts }) {
  const violations = [];
  const o = structuredClone(out);
  if (o.safety_concern) { o.questions = []; return { out: o, blocking: [], violations }; }
  const max = 3;
  if (o.questions.length > max) { o.questions = o.questions.slice(0, max); violations.push('more than 3 questions (trimmed)'); }
  for (const q of o.questions) {
    if (q.targets_quote && !isVerbatim(q.targets_quote, userTexts)) { q.targets_quote = null; violations.push('targets_quote not verbatim (removed)'); }
    if (level !== 4) q.critic = null;
  }
  const blocking = [];
  if (o.questions.length < 2) blocking.push('fewer than 2 questions');
  if (level === 4 && o.questions.length !== 3) blocking.push('Level 4 needs exactly 3 questions');
  for (const q of o.questions) {
    if (!q.question.trim().endsWith('?')) blocking.push(`not a question: "${q.question}"`);
    if (isLeading(q.question)) blocking.push(`leading question: "${q.question}"`);
    const d = findDirectAnswer(q.question);
    if (d) blocking.push(`direct answer: "${d}"`);
  }
  const d = findDirectAnswer(o.intro);
  if (d) blocking.push(`direct answer in intro: "${d}"`);
  return { out: o, blocking, violations: [...violations, ...blocking] };
}

/** Bias flags: keep only confident, evidenced, new flags (max 2). */
export function checkBiases(out, { userTexts, alreadyFlagged = [] }) {
  const violations = [];
  const seen = new Set(alreadyFlagged);
  const kept = [];
  for (const f of out.flags) {
    if (!BIASES[f.bias_id]) { violations.push(`unknown bias ${f.bias_id}`); continue; }
    if (f.confidence === 'uncertain') continue;
    if (seen.has(f.bias_id)) continue;
    if (!isVerbatim(f.quote, userTexts)) { violations.push(`${f.bias_id}: quote not found in user text (dropped)`); continue; }
    if (findDirectAnswer(f.explanation)) { violations.push(`${f.bias_id}: explanation gives advice (dropped)`); continue; }
    seen.add(f.bias_id);
    kept.push(f);
    if (kept.length === 2) break;
  }
  return { out: { flags: kept }, blocking: [], violations };
}

/** Reasoning map: quoted nodes must be verbatim, unknowns are always marked inferred. */
export function checkMap(out, { userTexts }) {
  const violations = [];
  const o = structuredClone(out);
  const ids = new Set();
  let unknowns = 0;
  o.nodes = o.nodes.filter(n => {
    n.id = String(n.id).replace(/[^A-Za-z0-9_]/g, '') || `n${ids.size + 1}`;
    if (n.id === 'claim' || ids.has(n.id)) { violations.push(`duplicate id ${n.id}`); return false; }
    if (n.type === 'unknown') {
      n.inferred = true; n.quote = null;
      if (++unknowns > 3) { violations.push('more than 3 unknowns (trimmed)'); return false; }
    } else {
      n.inferred = false;
      if (!isVerbatim(n.quote, userTexts)) { violations.push(`${n.type} node "${n.text}": quote not found (removed)`); return false; }
    }
    ids.add(n.id);
    return true;
  }).slice(0, 8);
  const valid = new Set(['claim', ...o.nodes.map(n => n.id)]);
  o.edges = o.edges.filter(e => valid.has(e.from) && valid.has(e.to) && e.from !== e.to);
  if (!isVerbatim(o.claim.quote, userTexts)) violations.push('claim quote not verbatim');
  return { out: o, blocking: [], violations };
}

/** Reflection nudge: no verdicts on the decision. */
export function checkReflection(out) {
  const blocking = [];
  for (const k of ['observation', 'message', 'next_question']) {
    const d = findDirectAnswer(out[k]);
    if (d) blocking.push(`direct answer in ${k}: "${d}"`);
  }
  if (!out.safety_concern && !out.next_question.trim().endsWith('?')) blocking.push('next_question does not end with "?"');
  return { out, blocking, violations: blocking };
}
