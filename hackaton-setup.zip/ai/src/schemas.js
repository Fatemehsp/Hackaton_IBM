// JSON schemas for structured outputs (output_config.format, type "json_schema").
// API constraints respected: every object has additionalProperties:false, every property is
// required, no min/max length or item limits (those are enforced in guards.js instead),
// nullable values use anyOf with {type:'null'}.

import { CITATION_IDS, BIAS_IDS } from './citations.js';

const str = { type: 'string' };
const bool = { type: 'boolean' };
const nullable = s => ({ anyOf: [s, { type: 'null' }] });
const obj = (properties) => ({ type: 'object', properties, required: Object.keys(properties), additionalProperties: false });

const techniqueId = nullable({ type: 'string', enum: CITATION_IDS });
const critic = { type: 'string', enum: ['Sceptical reviewer', 'Domain expert', 'Premortem'] };
const signal = obj({ present: bool, quote: nullable(str) });

export const COACH_SCHEMA = obj({
  message: str,
  question: str,
  hint: nullable(str),
  panel: { type: 'array', items: obj({ critic, objection: str }) },
  technique_id: techniqueId,
  pending: { type: 'string', enum: ['assumption', 'counter', 'falsify', 'evidence', 'none'] },
  can_advance: bool,
  signals: obj({ named_assumption: signal, engaged_other_side: signal, stated_falsifier: signal }),
  safety_concern: bool,
});

export const SOCRATIC_SCHEMA = obj({
  intro: str,
  questions: {
    type: 'array',
    items: obj({
      question: str,
      type: { type: 'string', enum: ['assumption', 'evidence', 'alternative', 'consequence', 'falsification'] },
      targets_quote: nullable(str),
      critic: nullable(critic),
    }),
  },
  technique_id: techniqueId,
  safety_concern: bool,
});

export const BIAS_SCHEMA = obj({
  flags: {
    type: 'array',
    items: obj({
      bias_id: { type: 'string', enum: BIAS_IDS },
      quote: str,
      explanation: str,
      confidence: { type: 'string', enum: ['high', 'medium', 'uncertain'] },
    }),
  },
});

export const MAP_SCHEMA = obj({
  claim: obj({ text: str, quote: str }),
  nodes: {
    type: 'array',
    items: obj({
      id: str,
      type: { type: 'string', enum: ['assumption', 'emotion', 'fact', 'unknown'] },
      text: str,
      quote: nullable(str),
      inferred: bool,
    }),
  },
  edges: {
    type: 'array',
    items: obj({ from: str, to: str, relation: { type: 'string', enum: ['supports', 'depends_on', 'contradicts'] } }),
  },
});

export const SKILLS = ['naming_assumptions', 'considering_other_side', 'stating_falsifiers', 'separating_evidence_from_opinion', 'calibrating_confidence', 'none'];

export const REFLECTION_SCHEMA = obj({
  change_type: { type: 'string', enum: ['revised', 'reaffirmed_tested', 'reaffirmed_untested'] },
  observation: str,
  message: str,
  next_question: str,
  skill_to_practice: { type: 'string', enum: SKILLS },
  practice_prompt: str,
  technique_id: techniqueId,
  safety_concern: bool,
});

export const ALL_SCHEMAS = { COACH_SCHEMA, SOCRATIC_SCHEMA, BIAS_SCHEMA, MAP_SCHEMA, REFLECTION_SCHEMA };
