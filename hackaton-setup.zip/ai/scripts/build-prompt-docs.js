// Generates PROMPTS.md from src/prompts.js so the document can never drift from the code.
import { writeFileSync } from 'node:fs';
import * as P from '../src/prompts.js';
import { CITATIONS, BIASES } from '../src/citations.js';
import { ALL_SCHEMAS } from '../src/schemas.js';

const block = t => '```text\n' + t.trim() + '\n```';
const md = `# Devil's AIdvocate — Prompt library

_Generated from \`src/prompts.js\` (version ${P.PROMPT_VERSION}). Edit the code, then run \`npm run docs\`._

Every coaching call uses **base rules + one level persona** as the system prompt, plus a **task** in the user message.
The Reasoning Mapper and Bias Detector are separate calls with their own system prompts on a faster model.
All calls return JSON that must match a schema (structured outputs), and are then checked by \`src/guards.js\`.

## 1. Shared base rules (part of every level)
${block(P.BASE_SYSTEM)}

## 2. Level personas
${[1, 2, 3, 4].map(L => `### Level ${L}\n${block(P.LEVEL_PROMPTS[L])}`).join('\n\n')}

## 3. Per-turn tasks
${Object.entries(P.TASKS).map(([k, v]) => `### ${k}\n${block(v)}`).join('\n\n')}

## 3b. Research notes block (RAG)
When the backend retrieves research notes, this block is added to every coaching input (example with one note):
${block(P.researchBlock([{ id: 'walton1997', finding: '<summary from the backend knowledge base>' }]))}

## 4. Socratic Question Generator (opens the Challenge step)
${block(P.SOCRATIC_TASK)}

## 5. Reflection Nudge (closes the session, feeds the spaced-repetition flag)
${block(P.REFLECTION_TASK)}

## 6. Reasoning Mapper (system prompt, fast model)
${block(P.MAPPER_SYSTEM)}

## 7. Bias Detector (system prompt, fast model)
${block(P.BIAS_SYSTEM)}

## 8. Verified citation whitelist
The model can only pick an id; the app shows the text below. Nothing else can be cited.

| id | Shown as | Full reference |
|---|---|---|
${Object.entries(CITATIONS).map(([id, c]) => `| \`${id}\` | ${c.label} | ${c.reference} |`).join('\n')}

## 9. Bias catalogue
| id | Name | Citation |
|---|---|---|
${Object.entries(BIASES).map(([id, b]) => `| \`${id}\` | ${b.name} | ${CITATIONS[b.cite].label} |`).join('\n')}

## 10. Output schemas
${Object.entries(ALL_SCHEMAS).map(([k, s]) => `### ${k}\n\`\`\`json\n${JSON.stringify(s, null, 2)}\n\`\`\``).join('\n\n')}
`;
writeFileSync(new URL('../PROMPTS.md', import.meta.url), md);
console.log(`PROMPTS.md written (${md.length.toLocaleString()} characters)`);
